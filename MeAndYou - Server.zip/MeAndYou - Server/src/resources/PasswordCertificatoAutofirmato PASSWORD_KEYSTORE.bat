/cd Desktop
keytool -genkeypair ^
 -alias meandyou ^
 -keyalg RSA ^
 -keysize 2048 ^
 -validity 365 ^
 -keystore keystore.p12 ^
 -storetype PKCS12 ^
 -storepass PASSWORD_KEYSTORE ^
 -keypass PASSWORD_KEYSTORE ^
 -dname "CN=MeAndYou, OU=Didattica, O=PersonalProject, L=Local, ST=NA, C=IT"
