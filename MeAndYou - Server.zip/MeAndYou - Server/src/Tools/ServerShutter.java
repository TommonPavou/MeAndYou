package Tools;

import javax.net.ssl.SSLServerSocket;
import java.util.concurrent.ExecutorService;

// Tiene traccia dei thread attivi
// Ne gestisce la chiusura in caso di un arresto forzato del server con la console
public class ServerShutter {
    // Inizializzazione e assegnazione delle variabili
    private static volatile boolean running = true;

    // Inizializzazione dei metodi vari
    private static SSLServerSocket serverSocket;
    private static ExecutorService threadPool;

    public static boolean isRunning() {
        return running;
    }

    public static void setServerSocket(SSLServerSocket socket) {
        serverSocket = socket;
    }

    public static void setThreadPool(ExecutorService pool) {
        threadPool = pool;
    }

    public static void arrestaThreads() {
        running = false;
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close(); // sblocca accept()
            }
        } catch (Exception ignored) {}

        if (threadPool != null && !threadPool.isShutdown()) {
            threadPool.shutdownNow(); // chiude i thread delle connessioni
        }
    }
}