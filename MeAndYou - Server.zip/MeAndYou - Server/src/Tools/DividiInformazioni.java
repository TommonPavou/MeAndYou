package Tools;

// Ottiene dai messaggi le informazioni separate dai delimitatori " | "
public class DividiInformazioni {
    // Inizializzazione di metodi vari
    MessageFilter filtroMessaggi = new MessageFilter();

    // Messaggio atteso: nomeUtente | scelta | contenuto
    // Il contenuto puo essere XXXXXX o messaggio
    public String ottieniNome(String testo) {
        String[] partiMessaggio = testo.split(" \\| ", 3);
        if (filtroMessaggi.verificaMessaggio(testo)) return partiMessaggio.length > 0 ? partiMessaggio[0].trim() : "";
        else return "";
    }

    public String ottieniAzioneScelta(String testo) {
        String[] partiMessaggio = testo.split(" \\| ", 3);
        return partiMessaggio.length > 1 ? partiMessaggio[1].trim() : "";
    }

    public String ottieniContenuto(String testo) {
        String[] partiMessaggio = testo.split(" \\| ", 3);
        return partiMessaggio.length > 2 ? partiMessaggio[2].trim() : "";
    }
}