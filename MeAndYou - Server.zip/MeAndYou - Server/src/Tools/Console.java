package Tools;

import Connessioni.GestioneConnessioni;
import Connessioni.GestioneConnessioniAttive;
import Connessioni.GestioneStanze;
import Avvio.Avvio;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.ThreadMXBean;
import java.util.Scanner;

// Classe per la gestione della console del server
public class Console implements Runnable {
    private static Console instance; // istanza condivisa accessibile con getInstance()

    // Inizializzazione e assegnazione delle variabili
    String inputConsole = "";
    String codiceStanza = "";
    String indirizzoIP = "";
    String motivo = "Motivazione non fornita";
    int valoreExtraNumerico = 1; // Valore di default
    private static volatile boolean output = true;
    private volatile boolean running = true;

    // Inizializzazione dello scanner condiviso
    private static final Scanner scanner = new Scanner(System.in);

    // Inizializzazione di metodi vari
    File cDrive = new File("C:");
    MemoryMXBean memoryMXBean = ManagementFactory.getMemoryMXBean();
    ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
    Avvio avvio = new Avvio();
    private final GestioneStanze gestioneStanze; // istanza condivisa

    // Costruttore che imposta l'istanza condivisa
    public Console(GestioneStanze gestioneStanze) {
        this.gestioneStanze = gestioneStanze;
        instance = this;
    }

    // Ritorna l'istanza della console (null se non inizializzata)
    public static Console getInstance() {
        return instance;
    }

    public void run() {
        while (running) {
            // Leggi input dall'utente
            inputConsole = scanner.nextLine();

            // Gestione parametro opzionale per CPU
            if (inputConsole.startsWith("/cpu ")) {
                try {
                    String[] parti = inputConsole.split(" ");
                    inputConsole = parti[0];
                    valoreExtraNumerico = Integer.parseInt(parti[1]);
                } catch (Exception erroreDivisioneMessaggio) {
                    // Nulla al momento
                }
            }

            // Gestione parametro per Kill
            if (inputConsole.startsWith("/killIP ")) {
                try {
                    String[] parti = inputConsole.split(" ");
                    inputConsole = parti[0];
                    indirizzoIP = (parti[1]);
                    motivo = (parti[2]);
                } catch (Exception erroreDivisioneMessaggio) {
                    // Nulla al momento
                }
            }

            // Gestione parametro per Kill stanza
            if (inputConsole.startsWith("/stanzaKill ")) {
                try {
                    String[] parti = inputConsole.split(" ");
                    inputConsole = parti[0];
                    codiceStanza = (parti[1]);
                    motivo = (parti[2]);
                } catch (Exception erroreDivisioneMessaggio) {
                    // Nulla al momento
                }
            }

            switch (inputConsole) {
                case "/help":
                    Logger.log(1, "/output true ->                      Visualizzare i messaggi di log");
                    Logger.log(1, "/output false ->                     Nascondere i messaggi di log");
                    Logger.log(1, "/disk ->                             Visualizzare lo spazio rimanente del disco");
                    Logger.log(1, "/cpu <secondi> ->                    Visualizzare l'utilizzo medio della CPU in un intervallo di tempo");
                    Logger.log(1, "/ram ->                              Visualizzare l'utilizzo della RAM attuale");
                    Logger.log(1, "/threads ->                          Visualizzare il numero di threads attivi");
                    Logger.log(1, "/kill <ip> <motivo> ->               Terminare una determinata sessione");
                    Logger.log(1, "/stanzaKill <codice> <motivo> ->     Chiudere una determinata stanza e scollegare tutti i partecipanti");
                    Logger.log(1, "/stanzaView <codice> ->              Visualizzare il numero di partecipanti in una stanza");
                    Logger.log(1, "/shutdown ->                         Arresta in modo sicuro il server");
                    Logger.log(1, "");
                    break;

                case "/output true":
                    Logger.log(1, "I messaggi di log sono ora visibili");
                    Logger.log(1, "");
                    output = true;
                    break;

                case "/output false":
                    Logger.log(1, "I messaggi di log non sono piu' visibili");
                    Logger.log(1, "");
                    output = false;
                    break;

                case "/disk":
                    Logger.log(1, String.format("Utilizzo disco: %.2f%%", ((double) (cDrive.getTotalSpace() - cDrive.getFreeSpace()) / cDrive.getTotalSpace()) * 100));
                    Logger.log(1, "");
                    break;

                case "/cpu":
                    Logger.log(1, "Calcolo utilizzo CPU medio in " + valoreExtraNumerico + " secondi...");
                    Logger.log(1, String.format("Utilizzo CPU: %.2f%%", ottieniUtilizzoCPU(valoreExtraNumerico)));
                    Logger.log(1, "");
                    break;

                case "/ram":
                    Logger.log(1, String.format("Utilizzo RAM: %.2f GB", (double) memoryMXBean.getHeapMemoryUsage().getUsed() / 1073741824));
                    Logger.log(1, "");
                    break;

                case "/threads":
                    Logger.log(1, "Numero massimo di thread:" + avvio.valoreConnessioniMassime());
                    Logger.log(1, "Numero di thread attivi: " + ThreadCounter.valore());
                    Logger.log(1, "Numero di thread usati per le connessioni: " + (ThreadCounter.valore() - 3));
                    Logger.log(1, "");
                    break;

                case "/killIP":
                    GestioneConnessioni gestioneConnessioni = GestioneConnessioniAttive.getConnessione(indirizzoIP);
                    if (gestioneConnessioni != null) {
                        if (motivo == null || motivo.isEmpty()) motivo = "Motivazione non fornita";
                        gestioneConnessioni.terminaSessioneSpecifica(motivo);
                        motivo = "Motivazione non fornita"; // Reimposta il valore di default
                        Logger.log(1, "INFO: Disconnessione in corso...");
                        Logger.log(1, "");
                    } else {
                        Logger.log(2, "WARN: Nessuna connessione trovata con il seguente IP: " + indirizzoIP);
                        Logger.log(1, "");
                    }
                    break;

                case "/stanzaKill":
                    if (gestioneStanze == null) {
                        Logger.log(2, "WARN: GestioneStanze non inizializzata");
                        break;
                    }
                    GestioneStanze.Stanza stanzaDaChiudere = gestioneStanze.ottieniStanza(codiceStanza);

                    if (stanzaDaChiudere != null) {
                        if (motivo == null || motivo.isEmpty()) motivo = "Motivazione non fornita";
                        stanzaDaChiudere.broadcast("ATTENZIONE: La stanza " + codiceStanza + " verrà chiusa tra 10 secondi. Motivo: " + motivo);
                        motivo = "Motivo non fornito"; // Reimposta il valore di default

                        // Timer di chiusura dopo 10 secondi (usa scheduler della gestione stanze)
                        gestioneStanze.schedule(() -> {
                            stanzaDaChiudere.chiudi();
                            Logger.log(1, "INFO: La stanza " + codiceStanza + " è stata chiusa con successo");
                        }, 10, java.util.concurrent.TimeUnit.SECONDS);
                    } else {
                        Logger.log(2, "WARN: Nessuna stanza trovata con codice " + codiceStanza);
                    }
                    break;

                case "/stanzaView":
                    if (gestioneStanze == null) {
                        Logger.log(2, "WARN: GestioneStanze non inizializzata");
                        break;
                    }
                    GestioneStanze.Stanza stanzaView = gestioneStanze.ottieniStanza(codiceStanza);

                    if (stanzaView != null) {
                        int membri = stanzaView.numeroPartecipanti();
                        Logger.log(1, "INFO: La stanza " + codiceStanza + " contiene attualmente " + membri + " membri");
                    } else {
                        Logger.log(2, "WARN: Nessuna stanza trovata con codice " + codiceStanza);
                    }
                    break;

                case "/shutdown":
                    Logger.log(1, "INFO: Arresto del server in corso...");
                    ServerShutter.arrestaThreads();
                    stop(); // Termina loop
                    break;

                default:
                    Logger.log(2, "Comando non valido. Digitare '/help' per la lista dei comandi");
                    Logger.log(1, "");
            }
        }
        scanner.close();
    }

    // Metodo per arrestare la console
    public void stop() {
        running = false;
    }

    // Metodo per ottenere l'utilizzo medio della CPU
    private double ottieniUtilizzoCPU(int tempoCampionamento) {
        int cores = Runtime.getRuntime().availableProcessors();

        long inizioTempoCPU = ottieniTempoCPU();
        long inizioTempoReale = System.nanoTime();

        try {
            Thread.sleep(tempoCampionamento* 1000L); // Intervallo di campionamento
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        long fineTempoCPU = ottieniTempoCPU();
        long fineTempoReale = System.nanoTime();

        long tempoCPU = fineTempoCPU - inizioTempoCPU;
        long tempoReale = fineTempoReale - inizioTempoReale;

        return (tempoCPU / (double) tempoReale) / cores * 100.0;
    }

    //Somma il tempo CPU di tutti i thread
    private long ottieniTempoCPU() {
        long totale = 0L;
        for (long idThread : threadMXBean.getAllThreadIds()) {
            long tempo = threadMXBean.getThreadCpuTime(idThread);
            if (tempo > 0) {
                totale += tempo;
            }
        }
        return totale;
    }

    public boolean valoreOutput(){
        return output;
    }
}
