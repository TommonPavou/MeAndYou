package Tools;

//Classe per il filtraggio dei messaggi fantoccio (vuoti) ricevuti
public class MessageFilter {
    public boolean verificaMessaggio(String testo) {
        String[] partiMessaggio = testo.split(" \\| ", 3); // Divide il testo usando i divisori " | "
        return !(partiMessaggio.length > 1 ? partiMessaggio[1].trim() : "").isEmpty(); // Verifica se il testo è vuoto
    }
}