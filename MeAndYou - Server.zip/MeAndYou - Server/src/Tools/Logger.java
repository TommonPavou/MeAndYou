package Tools;

// Classe per la gestione della stampa di messaggi colorati in console
public class Logger {
    // Codici ANSI per i colori
    private static final String RESET = "\u001B[0m";
    private static final String WHITE = "\u001B[37m";
    private static final String YELLOW = "\u001B[33m";
    private static final String RED = "\u001B[31m";

    public static void log(int codiceColore, String messaggio) {
        String color = switch (codiceColore) {
            case 2 -> YELLOW;
            case 3 -> RED;
            default -> WHITE;
        };

        System.out.println(color + messaggio + RESET);
    }
}