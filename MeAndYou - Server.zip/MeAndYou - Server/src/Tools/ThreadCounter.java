package Tools;

// Questa classe serve per tenere traccia del numero di thread attivi
// Serve a ridurre il numero di risorse usate nell' accettazione di connessioni quando il limite e' stato raggiunto
public class ThreadCounter {
    private static int threadCount = 0;
    private static final Object controlloSync = new Object();

    public static void incremento() {
        synchronized (controlloSync) {
            threadCount++;
        }
    }

    public static void decremento() {
        synchronized (controlloSync) {
            threadCount--;
        }
    }

    public static int valore() {
        synchronized (controlloSync) {
            return threadCount;
        }
    }
}