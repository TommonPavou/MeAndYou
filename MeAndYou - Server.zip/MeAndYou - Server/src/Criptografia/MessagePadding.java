package Criptografia;

import Tools.Logger;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

// Classe per aggiunge e rimuove il padding dai messaggi
public class MessagePadding {
    // Dichiarazione e assegnazione di metodi vari
    private static final SecureRandom secureRandom = new SecureRandom();

    // Prepara un messaggio con il prefisso LEN e il padding con SecureRandom
    public static byte[] addPadding(String messaggioChiaro, int lunghezzaTotale, String clientIP) {
        byte[] data = messaggioChiaro.getBytes(StandardCharsets.UTF_8);
        String prefisso = "LEN:" + data.length + "|";
        byte[] prefissoBytes = prefisso.getBytes(StandardCharsets.UTF_8);

        int paddingTotale = prefissoBytes.length + data.length;
        if (paddingTotale > lunghezzaTotale) {
            Logger.log(3, clientIP + " ERROR: Messaggio troppo lungo per la dimensione target");
            throw new IllegalArgumentException();
        }

        int paddingRimasto = lunghezzaTotale - paddingTotale;
        byte[] padding = new byte[paddingRimasto];
        secureRandom.nextBytes(padding);

        byte[] messaggioFinale = new byte[lunghezzaTotale];
        System.arraycopy(prefissoBytes, 0, messaggioFinale, 0, prefissoBytes.length);
        System.arraycopy(data, 0, messaggioFinale, prefissoBytes.length, data.length);
        System.arraycopy(padding, 0, messaggioFinale, paddingTotale, paddingRimasto);

        return messaggioFinale;
    }

    // Estrae il messaggio reale dal prefisso LEN e il padding
    public static String removePadding(byte[] plainText, String clientIP) {
        String decoded = new String(plainText, StandardCharsets.UTF_8);
        int indiceSeparatore = decoded.indexOf('|');
        if (indiceSeparatore == -1 || !decoded.startsWith("LEN:")) {
            Logger.log(3, clientIP + " ERROR: Formato del messaggio fornito non valido");
            throw new IllegalStateException();
        }

        int lunghezzaOriginale = Integer.parseInt(decoded.substring(4, indiceSeparatore));
        return decoded.substring(indiceSeparatore + 1, indiceSeparatore + 1 + lunghezzaOriginale);
    }
}