package Criptografia;

import Tools.Console;
import Tools.Logger;

import javax.crypto.*;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.spec.DHParameterSpec;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;

/* Diffie-Hellman (DHke) è un algoritmo di scambio chiavi che consente a due parti di stabilire una chiave
segreta comune attraverso un canale insicuro. Ognuno genera una chiave privata e la corrispondente chiave pubblica.
Dopo lo scambio delle chiavi pubbliche, ciascuna parte combina quella ricevuta con la propria chiave privata,
ottenendo così la stessa chiave condivisa, grazie alle proprietà matematiche dell’esponenziazione modulare.

La chiave grezza ottenuta non sempre è direttamente utilizzabile per crittografare:
spesso viene passata attraverso una funzione di derivazione (es. SHA-256 o HKDF)
per ottenere una chiave di lunghezza fissa e adatta a un algoritmo simmetrico (come AES).

Un attaccante che intercettasse solo le chiavi pubbliche non avrebbe la possibilità di calcolare
la chiave condivisa senza conoscere le private, poiché questo richiederebbe risolvere il problema
del logaritmo discreto, considerato computazionalmente impraticabile con parametri sufficientemente grandi. */

/* - Chiave privata: è un'informazione segreta generata localmente, che deve rimanere protetta.
Non deve mai essere condivisa. Serve a calcolare il segreto condiviso insieme alla chiave pubblica del destinatario.

- Chiave pubblica: è l'informazione che può essere inviata ad altri. Permette, unita alla
chiave privata, di calcolare lo stesso segreto condiviso in maniera sicura senza
trasmetterlo in chiaro.

- IV (Initialization Vector): è un valore di inizializzazione utilizzato negli algoritmi di cifratura.
Nel caso di AES-GCM, ha lunghezza raccomandata di 12 byte. È essenziale per cifrare e decifrare i messaggi
e deve essere univoco ogni volta che si invia o riceve del testo e sincronizzato tra le macchine, altrimenti
la sicurezza dell'algoritmo viene compromessa.

- Sale crittografico: è un valore casuale (spesso generato con SecureRandom) usato in funzioni di derivazione
chiave (come HKDF) per aumentare la sicurezza.

- HKDF (HMAC-based Key Derivation Function): è una funzione di derivazione che, partendo da un segreto
(come quello ottenuto con Diffie-Hellman), produce materiale chiave sicuro e di lunghezza arbitraria.
Questo permette di ricavare più chiavi distinte (es. AES, IV, Session ID) dallo stesso segreto condiviso.

HMAC (Hash-based Message Authentication Code): è uno specifico messaggio di autentificazione che involve
una funzione hash crittografica (come SHA-256) e una chiave segreta. Viene usato in HKDF per garantire
l'integrità e l'autenticità del materiale chiave derivato.

- Label: stringhe come "||aes-key", "||base-iv", "||session-id" vengono concatenate al parametro `info`
di HKDF per realizzare una *domain separation*. In questo modo, anche usando lo stesso segreto di partenza,
ogni derivata ha un ruolo univoco e non può essere confusa o riutilizzata accidentalmente per scopi diversi.

- AES in modalità GCM (Galois/Counter Mode): è un algoritmo di cifratura simmetrica che fornisce sia la
confidenzialità (cifratura) che l'integrità/autenticazione dei messaggi. Funziona con un contatore
incrementato per ogni blocco e calcola un tag di autenticazione (GCM tag), verificato in fase di decifratura.
La sicurezza dipende dall’unicità dell’IV e dall’uso corretto del tag.

- AAD (Additional Authenticated Data): sono dati aggiuntivi non cifrati ma autenticati insieme al messaggio.
Vengono passati alla modalità GCM con `updateAAD()`. Se l’AAD non corrisponde in fase di decifratura,
l’operazione fallisce. In genere contengono identificativi di sessione, numeri di sequenza o altre
informazioni che devono essere protette contro modifiche ma non necessitano di confidenzialità.

- Informazione contestuale opzionale: in HKDF (contextInfo nel codice) serve a distinguere a cosa servirà quella chiave
derivata. Puo' essere una stringa/byte array. Non influisce sulla sicurezza matematica dell’HKDF,
ma impedisce confusione tra chiavi diverse derivate dallo stesso segreto. */

// Classe principale per la gestione dello scambio di chiavi Diffie-Hellman e la crittografia AES-GCM
public class DHke {
    // Inizializzazione dell'indirizzo IP del client
    static String clientIP;

    public DHke(String clientIP) {
        if (clientIP == null || clientIP.isEmpty()){
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Indirizzo IP del client non valido o nullo");
            throw new IllegalArgumentException();
        }
        DHke.clientIP = clientIP;
    }

    // Inizializazione e assegnazione delle costanti
    private static final int DIMENSIONE_DH_BIT = 2048; // Dimensione gruppo DH (2048 bit)
    private static final int DIMENSIONE_AES_BYTE = 32; // AES-256 (32 Byte)
    private static final int DIMENSIONE_TAG_GCM_BIT = 128; // Autenticazione GCM (128 bit)
    private static final int DIMENSIONE_IV_GCM_BYTE = 12; // IV raccomandato per GCM (12 bytes)
    private static final int DIMENSIONE_SESSION_ID_BYTE = 16; // ID sessione da 128 bit
    private static final int DIMENSIONE_SALE_CRITTOGRAFICO_BYTE = 32; // Salle crittografico da 32 bytes
    private static final int LUNGHEZZA_MESSAGGI_CRIPTATI_BYTE = 256; // Lunghezza dei messaggi desiderata con il padding (256 bytes)

    // Inizializzazione e assegnazione delle variabili
    private KeyPair coppiaChiavi; // Coppia di chiavi DH locali (privata + pubblica)
    private PublicKey chiavePubblica; // Chiave pubblica ricevuta dal peer
    private SecretKey chiaveAES; // Chiave AES-256 derivata con HKDF
    private byte[] datiAutentificativiAddizionali; // Dati Autentificativi addizionali per la modalita' GCM
    private byte[] vettoreInizializzazioneIngresso; // IV di base derivato incrementale (per messaggi in ingresso)
    private byte[] vettoreInizializzazioneUscita; // IV di base derivato incrementale (per messaggi in uscita)
    private byte[] sessionID; // ID sessione derivato dal segreto condiviso
    long contatoreMessaggiIngresso = 1L;
    long contatoreMessaggiUscita = 1L;

    // Dichiarazione e assegnazione di metodi vari
    static Console console = null;

    // -------------------------------------- METODI PRIMARIE PER L'HANDSHAKE -----------------------------------
    // Genera i parametri e la coppia di chiavi DH (2048 bit o 256 bytes)
    public void generaCoppiaChiavi() throws GeneralSecurityException {
        AlgorithmParameterGenerator generatoreParametri = AlgorithmParameterGenerator.getInstance("DH");
        generatoreParametri.init(DIMENSIONE_DH_BIT);
        AlgorithmParameters parametri = generatoreParametri.generateParameters();
        DHParameterSpec parametriDH = parametri.getParameterSpec(DHParameterSpec.class);

        KeyPairGenerator generatoreChiavi = KeyPairGenerator.getInstance("DH");
        generatoreChiavi.initialize(parametriDH);
        this.coppiaChiavi = generatoreChiavi.generateKeyPair();
    }

    // Imposta la chiave pubblica del client da una stringa codificata in Base64
    public void impostaChiavePubblicaDaB64(String chiavePubblicaClientB64) throws GeneralSecurityException {
        byte[] chiavePubblicaCodificata = Base64.getDecoder().decode(chiavePubblicaClientB64);
        KeyFactory fabbrica = KeyFactory.getInstance("DH");
        this.chiavePubblica = fabbrica.generatePublic(new X509EncodedKeySpec(chiavePubblicaCodificata));

        if (!(chiavePubblica instanceof DHPublicKey)) {
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: La chiave pubblica fornita non e' valida!");
            throw new InvalidKeyException();
        }
    }

    // Esegue lo scambio di chiavi DH e deriva una chiave AES-256, IV tramite HKDF-SHA256 e un ID sessione tramite HKDF-SHA256
    public void derivaChiaveAES(byte[] saleCrittografico) throws GeneralSecurityException {
        if (coppiaChiavi == null || chiavePubblica == null) {
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Errore durante la derivazione della chiave AES!");
            throw new IllegalStateException();
        }

        // Calcolo del segreto condiviso
        KeyAgreement accordoChiavi = KeyAgreement.getInstance("DH");
        accordoChiavi.init(coppiaChiavi.getPrivate());
        accordoChiavi.doPhase(chiavePubblica, true);
        byte[] segretoCondiviso = accordoChiavi.generateSecret();

        // HKDF-SHA256: estrazione + espansione
        byte[] chiaveRandomTemporanea = hkdfExtract(saleCrittografico, segretoCondiviso);

        // 2) Deriva materiali separati con info diverse partendo dalla chiave temporanea
        byte[] chiaveAESBytes = hkdfExpand(chiaveRandomTemporanea, "aes-key".getBytes(StandardCharsets.UTF_8), DIMENSIONE_AES_BYTE);
        byte[] ivIngressoBytes = hkdfExpand(chiaveRandomTemporanea, "base-iv".getBytes(StandardCharsets.UTF_8), DIMENSIONE_IV_GCM_BYTE);
        byte[] ivUscitaBytes = hkdfExpand(chiaveRandomTemporanea, "base-iv".getBytes(StandardCharsets.UTF_8), DIMENSIONE_IV_GCM_BYTE);
        byte[] sessionIDBytes = hkdfExpand(chiaveRandomTemporanea, "session-id".getBytes(StandardCharsets.UTF_8), DIMENSIONE_SESSION_ID_BYTE);

        this.chiaveAES = new SecretKeySpec(chiaveAESBytes, "AES");
        this.vettoreInizializzazioneIngresso = ivIngressoBytes;
        this.vettoreInizializzazioneUscita = ivUscitaBytes;
        this.sessionID = Arrays.copyOf(sessionIDBytes, sessionIDBytes.length);

        // Svuota gli array temporanei per sicurezza
        Arrays.fill(segretoCondiviso, (byte)0);
        Arrays.fill(chiaveRandomTemporanea, (byte)0);
        Arrays.fill(chiaveAESBytes, (byte)0);
        Arrays.fill(sessionIDBytes, (byte)0);
        Arrays.fill(ivUscitaBytes, (byte)0);
        Arrays.fill(ivIngressoBytes, (byte)0);
    }

    // ------------------------------------- METODI SECONDARI PER L'HANDSHAKE -----------------------------------
    // Trasforma il segreto condiviso in una chiave temporanea (pseudo) casuale
    private static byte[] hkdfExtract(byte[] saleCrittografico, byte[] segretoCondiviso) throws GeneralSecurityException {
        Mac hmacSHA256 = Mac.getInstance("HmacSHA256");

        // Se il salt è nullo o vuoto lo si inizializza
        if (saleCrittografico == null || saleCrittografico.length == 0){
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Sale crittografico non inizializzato o nullo");
            throw new IllegalStateException();
        }

        SecretKeySpec chiave = new SecretKeySpec(saleCrittografico, "HmacSHA256");
        hmacSHA256.init(chiave);
        return hmacSHA256.doFinal(segretoCondiviso);
    }

    // Espande la chiave temoranea (pseudo) casuale in una chiave finale di lunghezza desiderata
    private static byte[] hkdfExpand(byte[] chiaveRandomTemporanea, byte[] etichettaChiave, int lunghezzaOutput) throws GeneralSecurityException {
        Mac hmacSHA256 = Mac.getInstance("HmacSHA256");
        SecretKeySpec chiaveSegreta = new SecretKeySpec(chiaveRandomTemporanea, "HmacSHA256");
        hmacSHA256.init(chiaveSegreta);

        int hashLength = 32; // Ogni HMAC-SHA256 produce 32 byte
        int iterations = (int) Math.ceil((double) lunghezzaOutput / hashLength);

        byte[] previousBlock = new byte[0]; // T(0) = stringa vuota
        byte[] risultatoBytesChiaveAES = new byte[lunghezzaOutput]; // buffer per il risultato finale
        int contatore = 0;

        // Ciclo per generare tanti blocchi da 32 byte finché non si raggiunge la lunghezza richiesta
        for (int blockIndex = 1; blockIndex <= iterations; blockIndex++) {
            hmacSHA256.reset();

            hmacSHA256.update(previousBlock);
            if (etichettaChiave != null) {
                hmacSHA256.update(etichettaChiave);
            }
            hmacSHA256.update((byte) blockIndex);

            // Calcoliamo il nuovo blocco T(i)
            previousBlock = hmacSHA256.doFinal();

            // Copiamo i byte calcolati dentro l’output finale
            int bytesToCopy = Math.min(hashLength, lunghezzaOutput - contatore);
            System.arraycopy(previousBlock, 0, risultatoBytesChiaveAES, contatore, bytesToCopy);
            contatore += bytesToCopy;
        }

        return risultatoBytesChiaveAES;
    }

    public String valoreChiavePubblicaLocaleDaB64() {
        if (coppiaChiavi == null){
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Errore durante la codifica della chiave pubblica in Base64!");
            throw new IllegalStateException();
        }
        return Base64.getEncoder().encodeToString(coppiaChiavi.getPublic().getEncoded());
    }

    // Generatore dell Additional Authentification Data (AAD)
    public void generaAdditionalAuthentificationData(String clientIP){
        if (sessionID == null){
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Impossibile generare l'AAD senza un ID sessione valido");
            throw new IllegalStateException();
        }
        this.datiAutentificativiAddizionali = (Base64.getEncoder().encodeToString(sessionID) + "|| from-server ||" + clientIP).getBytes();
    }

    // Generatore di sale crittografico con SecureRandom
    public static byte[] generaSaleCrittografico() {
        byte[] sale = new byte[DIMENSIONE_SALE_CRITTOGRAFICO_BYTE];
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextBytes(sale);
        return sale;
    }

    // ----------------------------------------- METODI PER I MESSAGGI ------------------------------------------
    // Metodo per cifrare un messaggio testuale e restituire Base64
    public String criptaMessaggio(String testoChiaro) throws GeneralSecurityException {
        if (chiaveAES == null) {
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Impossibile criptare il messaggio senza una chiave AES");
            throw new IllegalStateException();
        }

        // Aggiornamento contatore messaggi e IV
        if (vettoreInizializzazioneUscita.length != DIMENSIONE_IV_GCM_BYTE) {
            // Controlla che l'IV abbia la lunghezza corretta (in AES-GCM di solito 12 byte)
            if (console.valoreOutput())
                Logger.log(3, clientIP + " ERROR: L'IV fornito non e' della corretta lunghezza");
            throw new IllegalArgumentException();
        }

        // Crea una copia dell'IV di base per non modificarlo direttamente in memoria
        byte[] ivUscitaRisultante = Arrays.copyOf(vettoreInizializzazioneUscita, vettoreInizializzazioneUscita.length);
        // Salva il valore corrente del contatore dei messaggi in uscita
        long contatoreMessaggiUscita = this.contatoreMessaggiUscita;

        // Aggiorna l'IV di ingresso aggiungendo il contatore byte per byte
        for (int i = vettoreInizializzazioneUscita.length - 1; i >= 0; i--) {
            long somma = (ivUscitaRisultante[i] & 0xFFL) + (contatoreMessaggiUscita & 0xFFL);
            ivUscitaRisultante[i] = (byte) (somma & 0xFF); // Aggiorna l'IV
            contatoreMessaggiUscita >>>= 8; // Considera l'eventuale riporto dopo 8 bit (255 valore massimo di ogni byte dell'IV)
        }

        // Aggiorna il vettore IV effettivo con la nuova versione
        vettoreInizializzazioneUscita = ivUscitaRisultante;
        // Incrementa il contatore globale dei messaggi in uscita per il prossimo messaggio
        this.contatoreMessaggiUscita++;

        // Inizializzazione del cifratore AES in modalità GCM
        Cipher cifratore = Cipher.getInstance("AES/GCM/NoPadding");
        // Specifica il tag di autenticazione e l'IV calcolato per questa cifratura
        GCMParameterSpec parametriCGM = new GCMParameterSpec(DIMENSIONE_TAG_GCM_BIT, vettoreInizializzazioneUscita);
        // Inizializza il cifratore con la chiave AES e l'IV aggiornato
        cifratore.init(Cipher.ENCRYPT_MODE, chiaveAES, parametriCGM);

        // Se presenti, aggiunge dati autenticativi addizionali (AAD) non cifrati ma verificati
        if (datiAutentificativiAddizionali != null) cifratore.updateAAD(datiAutentificativiAddizionali);

        // Applica LEN + Padding prima della cifratura
        byte[] paddedMessage = MessagePadding.addPadding(testoChiaro, LUNGHEZZA_MESSAGGI_CRIPTATI_BYTE, clientIP); // Lunghezza dei messaggi standardizzata
        byte[] missaggioCriptato = cifratore.doFinal(paddedMessage);

        return inBase64(missaggioCriptato);
    }

    // Metodo per decifrare un messaggio in Base64 e restituire il testo
    public String decifraMessaggio(String testoCifratoB64) throws GeneralSecurityException {
        if (chiaveAES == null) {
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Impossibile decifrare il messaggio senza una chiave AES");
            throw new IllegalStateException();
        }

        // Aggiornamento contatore messaggi e IV
        if (vettoreInizializzazioneIngresso.length != DIMENSIONE_IV_GCM_BYTE) {
            // Verifica che l'IV ricevuto abbia la lunghezza corretta (in AES-GCM di solito 12 byte)
            if (console.valoreOutput())
                Logger.log(3, clientIP + " ERROR: L'IV fornito non e' della corretta lunghezza");
            throw new IllegalArgumentException();
        }

        // Crea una copia dell'IV di base per la decifratura
        byte[] ivIngressoRisultante = Arrays.copyOf(vettoreInizializzazioneIngresso, vettoreInizializzazioneIngresso.length);
        // Ottiene il contatore dei messaggi in ingresso, che serve a generare l'IV corretto
        long contatoreMessaggiIngresso = this.contatoreMessaggiIngresso;

        // Aggiorna l'IV di ingresso aggiungendo il contatore byte per byte
        for (int i = vettoreInizializzazioneIngresso.length - 1; i >= 0; i--) {
            long somma = (ivIngressoRisultante[i] & 0xFFL) + (contatoreMessaggiIngresso & 0xFFL);
            ivIngressoRisultante[i] = (byte) (somma & 0xFF); // Aggiorna l'IV
            contatoreMessaggiIngresso >>>= 8; // Considera l'eventuale riporto dopo 8 bit (255 valore massimo di ogni byte dell'IV)
        }

        // Aggiorna l'IV effettivo con la versione modificata
        vettoreInizializzazioneIngresso = ivIngressoRisultante;
        // Incrementa il contatore globale dei messaggi in ingresso
        this.contatoreMessaggiIngresso++;

        // Conversione del testo cifrato da Base64 a byte
        byte[] testoCifrato = inByte(testoCifratoB64);
        // Inizializzazione del decifratore AES in modalità GCM
        Cipher decifratore = Cipher.getInstance("AES/GCM/NoPadding");
        // Specifica il tag di autenticazione e l'IV corrispondente usato nella cifratura
        GCMParameterSpec parametriCGM = new GCMParameterSpec(DIMENSIONE_TAG_GCM_BIT, vettoreInizializzazioneIngresso);
        // Inizializza il decifratore con la chiave AES e l'IV corretto
        decifratore.init(Cipher.DECRYPT_MODE, chiaveAES, parametriCGM);

        // Se erano stati usati dati autenticativi addizionali (AAD) in cifratura, vanno forniti anche qui
        if (datiAutentificativiAddizionali != null) decifratore.updateAAD(datiAutentificativiAddizionali);
        // Decifra il testo e verifica automaticamente il tag di autenticazione.
        // Rimuovi LEN + padding e restituisci il messaggio vero
        byte[] messaggioChiaro = decifratore.doFinal(testoCifrato);
        return MessagePadding.removePadding(messaggioChiaro, clientIP);
    }

    // Conversione in Base64 da byte[]
    public static String inBase64(byte[] datiInByte) {
        return Base64.getEncoder().encodeToString(datiInByte);
    }

    // Conversione in byte[] da Base64
    public static byte[] inByte(String datiInSringa) {
        return Base64.getDecoder().decode(datiInSringa);
    }

    // ---------------------------------- METODI NON USATI (possibilmente in futuro) ----------------------------
    // Restituisce la chiave AES-256 derivata
    public SecretKey valoreChiaveAES() {
        return chiaveAES;
    }

    // Restituisce l’IV di base derivato (Ingresso)
    public byte[] valoreVettoreInizializzazioneIngresso() {
        return vettoreInizializzazioneIngresso;
    }

    // Restituisce l’IV di base derivato (Uscita)
    public byte[] valoreVettoreInizializzazioneUscita() {
        return vettoreInizializzazioneUscita;
    }

    // Restituisce il contatore dei messaggi (Ingresso)
    public long valoreContatoreMessaggiIngresso() {
        return contatoreMessaggiIngresso;
    }

    // Restituisce il contatore dei messaggi (Uscita)
    public long valoreContatoreMessaggiUscita() {
        return contatoreMessaggiUscita;
    }

    // Restituisce l'ID sessione
    public byte[] valoreIDSessione() {
        return sessionID;
    }
}