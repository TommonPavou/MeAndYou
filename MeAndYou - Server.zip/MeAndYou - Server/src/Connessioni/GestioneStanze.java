package Connessioni;

import java.io.BufferedWriter;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

// Classe per la gestione della creazione, eliminazione e conta delle stanze
public class GestioneStanze implements Runnable{
    static final String CARATTERI = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private final ConcurrentHashMap<String, Stanza> stanze = new ConcurrentHashMap<>();
    int DURATA_STANZA_MINUTI = 20; // Valore di default
    private final SecureRandom secureRandom = new SecureRandom();

    // Scheduler single-thread per serializzare tutte le operazioni sulle stanze
    private ScheduledExecutorService scheduler;
    private final AtomicBoolean started = new AtomicBoolean(false);

    // Avvia il singolo thread dedicato alla gestione stanze
    public synchronized void start() {
        if (started.compareAndSet(false, true)) {
            scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread thread = new Thread(r, "GestioneStanze-Thread");
                thread.setDaemon(true);
                return thread;
            });
        }
    }

    // Arresta il thread e pulisce risorse
    public synchronized void stop() {
        if (started.compareAndSet(true, false)) {
            try {
                // Chiudi tutte le stanze
                for (String codice : stanze.keySet()) {
                    Stanza stanza = stanze.get(codice);
                    if (stanza != null) stanza.chiudi();
                }
                stanze.clear();
                if (scheduler != null && !scheduler.isShutdown()) {
                    scheduler.shutdownNow();
                }
            } catch (Exception ignored) {}
        }
    }

    // Esegue un task in modo sincrono sul thread delle stanze e ritorna risultato
    private <T> T executeSync(Callable<T> task) {
        if (scheduler == null) throw new IllegalStateException("GestioneStanze non avviata");
        // Se siamo già nel thread dello scheduler, esegui direttamente per evitare deadlock
        if (isSchedulerThread()) {
            try {
                return task.call();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        Future<T> future = scheduler.submit(task);
        try {
            return future.get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e.getCause());
        }
    }

    // Esegue un task asincrono (senza attendere)
    private void executeAsync(Runnable task) {
        if (scheduler == null) throw new IllegalStateException("GestioneStanze non avviata");
        // Se siamo già nel thread dello scheduler, esegui direttamente
        if (isSchedulerThread()) {
            task.run();
            return;
        }
        scheduler.execute(task);
    }

    // Permette di scheduleare un task con delay (usato dai timer delle stanze)
    public ScheduledFuture<?> schedule(Runnable eseguibile, long ritardo, TimeUnit unitaTempo) {
        if (scheduler == null) throw new IllegalStateException("GestioneStanze non avviata");
        return scheduler.schedule(eseguibile, ritardo, unitaTempo);
    }

    // Controlla se il thread corrente è il thread dello scheduler (nome impostato in start)
    private boolean isSchedulerThread() {
        return Thread.currentThread().getName().equals("GestioneStanze-Thread");
    }

    // Implementazione del run per l'esecuzione persistente della gestione stanze
    @Override
    public void run() {
        // Avvia lo scheduler (se non già avviato)
        start();
        try {
            // Rimani in vita finché non viene chiamato stop()
            while (started.get()) {
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        } finally {
            // Garantito cleanup
            stop();
        }
    }

    // Genera un codice stanza casuale a 6 caratteri
    private String generaCodiceInterno() {
        String codice;
        do {
            StringBuilder stringBuilder = new StringBuilder(6);
            for (int i = 0; i < 6; i++) {
                int index = secureRandom.nextInt(CARATTERI.length());
                stringBuilder.append(CARATTERI.charAt(index));
            }
            codice = stringBuilder.toString();
        } while (stanze.containsKey(codice));
        return codice;
    }

    // Crea una nuova stanza (sincrono, eseguito sul thread dedicato)
    public String creaStanza() {
        return executeSync(() -> {
            String codice = generaCodiceInterno();
            Stanza stanza = new Stanza(codice, DURATA_STANZA_MINUTI, this);
            stanze.put(codice, stanza);
            stanza.avviaTimer();
            return codice;
        });
    }

    // Recupera stanza esistente (restituisce riferimento alla stanza; le operazioni sulla stanza sono internamente serializzate)
    public Stanza ottieniStanza(String codice) {
        // Accesso sincronizzato sul thread delle stanze per coerenza
        return executeSync(() -> stanze.get(codice));
    }

    // Rimuove stanza (sincrono)
    public void rimuoviStanza(String codice) {
        executeAsync(() -> stanze.remove(codice));
    }

    // Classe interna per gestire i partecipanti
    public static class Stanza {
        private final String codice;
        private final Set<BufferedWriter> partecipanti = Collections.synchronizedSet(new HashSet<>());
        private final int durataMinuti;
        private final GestioneStanze gestioneStanze;
        private ScheduledFuture<?> chiusuraTask;

        public Stanza(String codice, int durataMinuti, GestioneStanze gestioneStanze) {
            this.codice = codice;
            this.durataMinuti = durataMinuti;
            this.gestioneStanze = gestioneStanze;
        }

        // Aggiunge partecipante in modo sincrono sullo scheduler della gestione stanze
        public void aggiungiPartecipante(BufferedWriter writer) {
            gestioneStanze.executeSync(() -> {
                partecipanti.add(writer);
                broadcast("SERVER: Un nuovo utente si è unito alla stanza.");
                return null;
            });
        }

        // Rimuove partecipante e chiude stanza se vuota (sincrono)
        public void rimuoviPartecipante(BufferedWriter writer) {
            gestioneStanze.executeSync(() -> {
                partecipanti.remove(writer);
                if (partecipanti.isEmpty()) {
                    chiudi();
                }
                return null;
            });
        }

        // Ottieni il numero aggiornato dei partecipanti di una specifica stanza
        public int numeroPartecipanti() {
            return gestioneStanze.executeSync(partecipanti::size);
        }

        // Broadcast del messaggio a tutti i partecipanti (eseguito sul thread della gestione stanze)
        public void broadcast(String messaggio) {
            gestioneStanze.executeAsync(() -> {
                synchronized (partecipanti) { // Sincronizza il numero di partecipanti al momento dell' invio
                    for (BufferedWriter writer : partecipanti) {
                        try {
                            synchronized (writer) { // Sincronizza il writer di GestioneStanze con quello di GestioneConnessioni
                                writer.write(messaggio + "\n");
                                writer.flush();
                            }
                        } catch (IOException ignored) {}
                    }
                }
            });
        }

        // Avvia il timer della stanza (usa lo scheduler della GestioneStanze)
        public void avviaTimer() {
            // Notifica immediata dopo pochi secondi
            gestioneStanze.schedule(() -> broadcast("SERVER: La stanza durerà " + durataMinuti + " minuti."),
                    10, TimeUnit.SECONDS);

            // Avviso a -5 minuti
            if (durataMinuti > 5) {
                gestioneStanze.schedule(() -> broadcast("SERVER: Mancano 5 minuti alla chiusura della stanza."),
                        (durataMinuti - 5), TimeUnit.MINUTES);
            }

            // Avviso a -1 minuto
            if (durataMinuti > 1) {
                gestioneStanze.schedule(() -> broadcast("SERVER: Manca 1 minuto alla chiusura della stanza."),
                        (durataMinuti - 1), TimeUnit.MINUTES);
            }

            // Task di chiusura
            chiusuraTask = gestioneStanze.schedule(() -> {
                broadcast("SERVER: La stanza è scaduta e verrà chiusa.");
                chiudi();
            }, durataMinuti, TimeUnit.MINUTES);
        }

        // Chiude la stanza definitivamente
        public void chiudi() {
            gestioneStanze.executeSync(() -> {
                if (chiusuraTask != null && !chiusuraTask.isDone()) {
                    chiusuraTask.cancel(false);
                }
                gestioneStanze.rimuoviStanza(codice);
                partecipanti.clear();
                return null;
            });
        }
    }
}