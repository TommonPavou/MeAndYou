package Connessioni;

import Criptografia.DHke;
import Tools.Console;
import Tools.Logger;
import Tools.ThreadCounter;
import Tools.ServerShutter;
import Tools.DividiInformazioni;

import javax.net.ssl.SSLSocket;
import java.io.*;
import java.security.GeneralSecurityException;

// Classe per la gestione delle connessioni in entrata e gestione dei messaggi
public class GestioneConnessioni implements Runnable {
    // Inizializzazione e assegnazione delle variabili
    String clientIP;
    String nomeUtente;

    // Assegnazione del ServerSocket
    public GestioneConnessioni(SSLSocket clientSocket, GestioneStanze gestioneStanze, String clientIP) {
        this.clientSocket = clientSocket;
        this.gestioneStanze = gestioneStanze;
        this.clientIP = clientIP;
    }

    // Inizializzazione e assegnazione delle variabili
    SSLSocket clientSocket;
    private BufferedWriter writer;

    // Dichiarazione e assegnazione di metodi vari
    DHke dhke;
    ProtezioneDoS protezioneDoS = new ProtezioneDoS();
    Tools.Console console = Console.getInstance(); // Usa l'istanza condivisa (impostata in Avvio)
    GestioneStanze gestioneStanze;
    private volatile GestioneStanze.Stanza stanzaCorrente;

    public void run() {
        // In attesa della connessione con un client
        try {
            clientIP = clientSocket.getInetAddress().getHostAddress();
            // inizializza dhke ora che abbiamo l'IP corretto
            dhke = new DHke(clientIP);
            // recupera l'istanza di Console (dovrebbe essere stata creata in Avvio)
            console = Console.getInstance();

            // Controllo corretto per connessione già esistente
            if (GestioneConnessioniAttive.getConnessione(clientIP) != null) {
                if (console != null && console.valoreOutput())
                    Logger.log(3, clientIP + " ERROR: Connessione interrotta, l'IP è gia' connesso");
                clientSocket.close();
                return; // termina subito la gestione di questa connessione
            }

            GestioneConnessioniAttive.registraConnessione(clientIP, this);
            if (!protezioneDoS.verificaConnessione(clientIP)) {
                if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Connessione interrotta per sospetto DoS");
                clientSocket.close();
                return;
            }

            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Connessione stabilita con il client");
        } catch (IOException | SecurityException | IllegalArgumentException erroreTestDoS) {
            if (console.valoreOutput())
                Logger.log(3, clientIP + " ERROR: Errore durante l'accettazione della connessione");
            Logger.log(3, erroreTestDoS.getMessage());
        }

        try {
            // Assegnazione della variabile per la ricezione dei messaggi
            String messaggioIngresso;

            // Assegnazione delle variabili per la ricezione e invio delle chiavi
            String chiavePubblicaServerB64;
            String chiavePubblicaClientB64;

            // Preparazione dei buffer per la comunicazione con il client e le variabili
            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Preparazione dei buffer in corso...");
            InputStream inputStream = clientSocket.getInputStream();
            OutputStream outputStream = clientSocket.getOutputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            this.writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Buffer impostati correttamente");

            // 1) Server genera le chiavi (privata e pubblica)
            dhke.generaCoppiaChiavi();
            chiavePubblicaServerB64 = dhke.valoreChiavePubblicaLocaleDaB64();

            // 2) Imposta il sale crittografico con SecureRandom
            byte[] saleCrittografico = DHke.generaSaleCrittografico();

            // 3) Invia DH1 (chiave pubblica server)
            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Invio della chiave DH1 in corso...");
            writer.write("DH1 " + chiavePubblicaServerB64 + " " + DHke.inBase64(saleCrittografico) + "\n");
            writer.flush();

            // 4) Riceve DH2 (chiave pubblica client)
            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Recezione della chiave DH2 in corso...");
            messaggioIngresso = reader.readLine();
            if (messaggioIngresso == null || !messaggioIngresso.startsWith("DH2 ")) { // Verifica che il messaggio sia la chiave DH2
                Logger.log(3, clientIP + " ERROR: Errore durante la ricezione della chiave DH2");
                throw new IOException();
            }
            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Chiave DH2 ricevuta");
            chiavePubblicaClientB64 = messaggioIngresso.split(" ", 2)[1].trim();
            dhke.impostaChiavePubblicaDaB64(chiavePubblicaClientB64);

            // 5) Accordo e derivazione chiave AES e AAD
            dhke.derivaChiaveAES(saleCrittografico);
            dhke.generaAdditionalAuthentificationData(clientIP);

            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Handshake DH completato!");

            // 6) Conferma al client che l'handshake è riuscito
            writer.write("handshake_completato\n");
            writer.flush(); // FINE KEY EXCHANGE
            if (console.valoreOutput()) Logger.log(1, "");

            // Classe per la divisione dei messaggi
            DividiInformazioni dividiInformazioni = new DividiInformazioni();

            // ------------------------------------------------------------------------------
            // NOTA: D'ora in avanti i messaggi sono criptati mediante la chiave AES derivata
            if (console.valoreOutput())
                Logger.log(1, clientIP + " INFO: Ricezione istruzioni e nome utente in corso...");
            while (true) { // Verifica se il messaggio successivo e' quello previsto
                messaggioIngresso = dhke.decifraMessaggio(reader.readLine());
                if (messaggioIngresso.contains("| crea_stanza | ") || messaggioIngresso.contains("| entra_stanza | "))
                    break;
            }

            // Ottiene il nome utente del client connesso dal messaggio ricevuto
            nomeUtente = dividiInformazioni.ottieniNome(messaggioIngresso);
            if (console.valoreOutput()) Logger.log(1, clientIP + "INFO: Nome utente del client: " + nomeUtente);

            // Inizializza la stanza dell'utente
            this.stanzaCorrente = null;

            // Assegnazioni delle variabili per la divisione dei messaggi di ingresso
            String scelta;
            String contenuto;

            // Loop principale per il ricevimento di messaggi dal client
            while (ServerShutter.isRunning()) {
                messaggioIngresso = dhke.decifraMessaggio(reader.readLine());

                scelta = dividiInformazioni.ottieniAzioneScelta(messaggioIngresso);
                contenuto = dividiInformazioni.ottieniContenuto(messaggioIngresso);

                // In base alla scelta inclusa nel messaggio completa una determinata azione
                switch (scelta) {
                    // Crea stanza e unisci l'utente
                    case "crea_stanza":
                        if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Creazione stanza in corso...");
                        String codiceStanza = gestioneStanze.creaStanza();
                        this.stanzaCorrente = gestioneStanze.ottieniStanza(codiceStanza);
                        stanzaCorrente.aggiungiPartecipante(writer);

                        writer.write(dhke.criptaMessaggio("stanza_creata | " + codiceStanza + "\n"));
                        writer.flush();

                        if (console.valoreOutput())
                            Logger.log(1, clientIP + " INFO: Stanza con codice " + codiceStanza + "generata con successo!");
                        break;

                    // Entra in una stanza pre esistente
                    case "entra_stanza":
                        if (console.valoreOutput())
                            Logger.log(1, clientIP + " INFO: Accesso in una stanza in corso...");
                        this.stanzaCorrente = gestioneStanze.ottieniStanza(contenuto); // Il contenuto risponde al codice della stanza
                        if (stanzaCorrente != null) {
                            writer.write(dhke.criptaMessaggio("entrato_nella_stanza | " + contenuto + "\n"));
                            stanzaCorrente.aggiungiPartecipante(writer);
                            writer.flush();

                            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Il client e' entrato nella stanza " + contenuto); // Il contenuto risponde al codice della stanza

                            stanzaCorrente.broadcast(dhke.criptaMessaggio("INFO: " + nomeUtente + " è entrato nella stanza."));
                        } else {
                            if (console.valoreOutput()) Logger.log(2, clientIP + " WARN: Errore nell' accesso alla stanza " + contenuto); // Il contenuto risponde al codice della stanza
                            writer.write(dhke.criptaMessaggio("errore_stanza_non_valida\n"));
                            writer.flush();
                        }
                        break;

                    // Scrivi un messaggio
                    case "msg":
                        if (stanzaCorrente != null) {
                            stanzaCorrente.broadcast(dhke.criptaMessaggio(nomeUtente + " | " + contenuto));
                            if (console.valoreOutput()) Logger.log(1, clientIP + ": " + nomeUtente + " | " + contenuto);
                        } else {
                            writer.write(dhke.criptaMessaggio("errore_non_in_stanza\n"));
                            writer.flush();
                            if (console.valoreOutput()) Logger.log(2, clientIP + " WARN: Errore nell' invio di un messaggio");
                        }
                        break;

                    // Messaggio fantasma
                    case "":
                        // Ignora il messaggio fantoccio
                        // Funzione non implementata nel codice (per ora)
                        break;

                    // Scelta non esistente
                    default:
                        writer.write(dhke.criptaMessaggio("errore_comando_non_valido\n"));
                        writer.flush();
                        if (console.valoreOutput()) Logger.log(2, clientIP + " WARN: Errore nell' interpretazione dell' istruzione " + scelta);
                        break;
                }
            }

        } catch (GeneralSecurityException erroreGeneraleDiSicurezza) {
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Errore crittografico durante lo scambio di chiavi");
            Logger.log(3, erroreGeneraleDiSicurezza.getMessage());
        } catch (IOException erroreConnessione) {
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Perdita di connessione durante la sessione");
            Logger.log(3, erroreConnessione.getMessage());
        } finally {
            try {
                if (console.valoreOutput()) Logger.log(3, clientIP + " INFO: Chiusura socket in corso...");
                if (stanzaCorrente != null && writer != null) {
                    stanzaCorrente.rimuoviPartecipante(writer);

                    // Notifica agli altri partecipanti solo se la stanza non è vuota
                    if (stanzaCorrente.numeroPartecipanti() > 0) {
                        try {
                            stanzaCorrente.broadcast(dhke.criptaMessaggio("SERVER: " + nomeUtente + " si è disconnesso"));
                        } catch (GeneralSecurityException e) {
                            Logger.log(3, clientIP + " ERROR: impossibile inviare la notifica di disconnessione");
                        }
                    }
                }

                // Chiusura della connessione
                clientSocket.close();
                GestioneConnessioniAttive.rimuoviConnessione(clientIP);
            } catch (IOException erroreChiusuraSocket) {
                if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Impossibile chiudere il socket ");
                Logger.log(3, erroreChiusuraSocket.getMessage());
            }
            // Aggiornamento numero thread attivi
            if (console.valoreOutput()) Logger.log(1, clientIP + " INFO: Sessione terminata!");
            ThreadCounter.decremento();
            if (console.valoreOutput()) Logger.log(1, "INFO: Numero di thread attivi aggiornato: " + ThreadCounter.valore());
        }
    }

        // Metodo per terminare la sessione in modo forzato (usato da ServerShutter)
        public void terminaSessioneSpecifica(String motivo) {
        try {
            if (stanzaCorrente != null && writer != null) {
                stanzaCorrente.broadcast(dhke.criptaMessaggio("SERVER: Disconnessione in corso di " + nomeUtente + ". Motivazione: " + motivo));
                stanzaCorrente.rimuoviPartecipante(writer);
            }

            // Chiusura della connessione e aggiornamento della lista/conta delle connessioni attive
            clientSocket.close();
            GestioneConnessioniAttive.rimuoviConnessione(clientIP);
        } catch (IOException | GeneralSecurityException e) {
            if (console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Chiusura forzata fallita!");
        }
        }
}

