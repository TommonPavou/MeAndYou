package Connessioni;

import java.util.concurrent.ConcurrentHashMap;

// Classe per la gestione e conta delle connessioni attive
public class GestioneConnessioniAttive {
    // Inizializzazione della HashMap per tenere traccia delle connessioni attive
    private static final ConcurrentHashMap<String, GestioneConnessioni> connessioniAttive = new ConcurrentHashMap<>();

    // Aggiungi un indirizzo IP alla lista di connessioni attive
    public static void registraConnessione(String ip, GestioneConnessioni conn) {
        connessioniAttive.put(ip, conn);
    }

    // Rimuovi una connessione dalla HashMap
    public static void rimuoviConnessione(String ip) {
        connessioniAttive.remove(ip);
    }

    // Ottieni una connessione dalla HashMap (usata per verificarne la sua presenza)
    public static GestioneConnessioni getConnessione(String ip) {
        return connessioniAttive.get(ip); // Restituisce null se non esiste
    }
}