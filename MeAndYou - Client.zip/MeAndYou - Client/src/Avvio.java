import Connessioni.GestioneConnessione;
import Tools.Logger;
import Tools.Console;

import javax.net.ssl.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.Scanner;

import static java.lang.Integer.getInteger;

// Classe principale per l'avvio del client
public class Avvio {
    public static void main(String[] args) throws InterruptedException {
        // Dichiarazione e assegnazione delle variabili
        int portaDefault = 1234;
        String indirizzoDefault = "localhost";
        boolean clientOnline = false;

        // Dichiarazione dei metodi vari
        Console console = new Console();
        Scanner scanner = new Scanner(System.in);

        // Dichiarazione dei metodi per stabilire connessioni
        SSLSocket socket = null;

        Logger.log(1, " _______  _______    __            _______          ");
        Logger.log(1, "(       )(  ____ \\  /__\\ |\\     /|(  ___  )|\\     /|");
        Logger.log(1, "| () () || (    \\/ ( \\/ )( \\   / )| (   ) || )   ( |");
        Logger.log(1, "| || || || (__      \\  /  \\ (_) / | |   | || |   | |");
        Logger.log(1, "| |(_)| ||  __)     /  \\/\\ \\   /  | |   | || |   | |");
        Logger.log(1, "| |   | || (       / /\\  /  ) (   | |   | || |   | |");
        Logger.log(1, "| )   ( || (____/\\(  \\/  \\  | |   | (___) || (___) |");
        Logger.log(1, "|/     \\|(_______/ \\___/\\/  \\_/   (_______)(_______)");
        Logger.log(1, "Il nostro luogo speciale dove IO & TE siamo sovrani <3");
        Logger.log(1, "Versione client: Alpha 0.0.1");
        Logger.log(1, "Server compatibili: Alpha 0.0.1");
        Logger.log(1, "--------------------------------------------------------");
        Logger.log(1, "");

        // Loop per il setup del client
        while (!clientOnline) {
            try {
                // Inserimento dell'indirizzo del server
                System.out.print("Inserisci l'indirizzo del server a cui connetterti (default: localhost): ");
                String indirizzoInserito = scanner.nextLine();
                if (!indirizzoInserito.isEmpty()) {
                    indirizzoInserito = indirizzoDefault;
                }
                // Inserimento della porta del server
                System.out.print("Inserisci la porta su cui avviare il server (default: 1234): ");
                int portaInserita = portaDefault;
                try {
                    portaInserita = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    Logger.log(2, "WARN: Porta non valida. Uso della porta di default");
                }

                // 1) Carica il keystore
                KeyStore keyStores = KeyStore.getInstance("PKCS12");
                InputStream keystoreStream = Avvio.class.getResourceAsStream("/keystore.p12");
                keyStores.load(keystoreStream, "PASSWORD_KEYSTORE".toCharArray());
                Logger.log(1, "INFO: Caricamento del keystore completata");

                // 2) Inizializza KeyManager
                KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
                kmf.init(keyStores, "PASSWORD_KEYSTORE".toCharArray());
                Logger.log(1, "INFO: Inizializzazione del keystore completata");

                // 3) Inizializza SSLContext
                SSLContext sc = SSLContext.getInstance("TLS");
                sc.init(kmf.getKeyManagers(), null, null);
                Logger.log(1, "INFO: Inizializzazione del socket completata");

                // 4) Crea SSLSocket
                Logger.log(1, "INFO: Connessione al server in corso...");
                SSLSocketFactory ssf = sc.getSocketFactory();
                socket = (SSLSocket) ssf.createSocket(indirizzoInserito, portaInserita);

                clientOnline = true;
                Logger.log(1, "INFO: Client TLS connesso a " + indirizzoInserito + " sulla porta " + portaInserita);
            } catch (IOException | SecurityException | IllegalArgumentException | NoSuchAlgorithmException |
                     CertificateException | KeyStoreException | UnrecoverableKeyException | KeyManagementException erroreCreazioneSocket) {
                Logger.log(3, "ERROR: Errore durante il setup del client");
                Logger.log(3, erroreCreazioneSocket.getMessage());
                Logger.log(1, "INFO: Prossimo tentativo tra 5 secondi...");
                Logger.log(1, "");
                Thread.sleep(5000); // Riprova dopo 5 secondi a creare il server
            }
        }

        // Avvio della console in un thread separato
        Thread consoleThread = new Thread(console);
        consoleThread.start();

        // Avvio la gestione della connessione con il server
        try {
            // Avvia la gestione connessione passando il socket in un thread separato
            GestioneConnessione gestione = new GestioneConnessione(socket);
            Thread gestioneThread = new Thread(gestione);
            gestioneThread.start();
        } catch (Exception erroreCreazioneThread) {
            if (console.valoreOutput()) {
                Logger.log(3, "ERROR: Errore durante la creazione della gestione connessione");
                Logger.log(3, erroreCreazioneThread.getMessage());
            }
        }
    }
}