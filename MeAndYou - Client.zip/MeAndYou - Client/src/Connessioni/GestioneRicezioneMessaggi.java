package Connessioni;

import Criptografia.DHke;
import Tools.Console;
import Tools.*;

import javax.net.ssl.SSLSocket;
import java.io.*;
import java.security.GeneralSecurityException;

public class GestioneRicezioneMessaggi implements Runnable{
    private final SSLSocket socket;
    private volatile Boolean running = true;

    public GestioneRicezioneMessaggi(SSLSocket socket){
        this.socket = socket;
    }

    public void updateRunningStatus(boolean running){
        this.running = running;
    }

    @Override
    public void run() {
        while (running) {
            DHke dhke = new DHke();
            Tools.Console console = new Console();

            String messaggioCifrato;
            String messaggioDecifrato;

            try {
                InputStream inputStream = socket.getInputStream();
                OutputStream outputStream = socket.getOutputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));

                messaggioCifrato = reader.readLine();
                messaggioDecifrato = dhke.decifraMessaggio(messaggioCifrato);

                Logger.log(1, messaggioDecifrato);

            } catch (IOException | GeneralSecurityException e) {
                throw new RuntimeException(e);
            }
        }
    }
}