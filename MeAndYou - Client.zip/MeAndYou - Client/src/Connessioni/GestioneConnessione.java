package Connessioni;

import Criptografia.DHke;
import Tools.*;
import Tools.Console;

import javax.net.ssl.SSLSocket;
import java.io.*;
import java.security.GeneralSecurityException;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;

// Classe per la gestione della connessione con il server e gestione dei messaggi
public class GestioneConnessione implements Runnable {
    // Dichiarazione e assegnazione delle variabili
    private SSLSocket socket;

    // Assegnazione del ServerSocket
    public GestioneConnessione(SSLSocket socket) {
        this.socket = socket;
    }

    // Assegnazione dell'indirizzo IP del client
    private final String indirizzoIP = String.valueOf(socket.getLocalAddress());

    // Dichiarazione e assegnazione di metodi vari
    DHke dhke = new DHke();
    Tools.Console console = new Console();
    Scanner scanner = new Scanner(System.in);
    GestioneRicezioneMessaggi gestioneRicezioneMessaggi = new GestioneRicezioneMessaggi(socket);

    public void run() {
        // Preparazione dei buffer per la comunicazione con il client e le variabili
        try {
            String messaggioIngresso;

            String chiavePubblicaClientB64;
            String chiavePubblicaServerB64;

            String nomeUtente;
            String codiceStanza = "";

            if (console.valoreOutput()) Logger.log(1, "INFO: Preparazione dei buffer in corso...");
            InputStream inputStream = socket.getInputStream();
            OutputStream outputStream = socket.getOutputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            if (console.valoreOutput()) Logger.log(1, "INFO: Buffer impostati correttamente");

            // 1) Client genera le chiavi (privata e pubblica)
            dhke.generaCoppiaChiavi();
            chiavePubblicaClientB64 = dhke.valoreChiavePubblicaLocaleDaB64();

            // 2) Imposta il sale crittografico con SecureRandom
            byte[] saleCrittografico = DHke.generaSaleCrittografico();

            // 2) Riceve DH1 (chiave pubblica server)
            if (console.valoreOutput()) Logger.log(1, "INFO: Recezione della chiave DH2 in corso...");
            messaggioIngresso = reader.readLine();
            if (messaggioIngresso == null || !messaggioIngresso.startsWith("DH1 ")) { // Verifica che il messaggio sia la chiave DH1
                Logger.log(3, "ERROR: Errore durante la ricezione della chiave DH2");
                throw new IOException();
            }
            if (console.valoreOutput()) Logger.log(1, "INFO: Chiave DH2 ricevuta");
            chiavePubblicaServerB64 = messaggioIngresso.split(" ", 2)[1].trim();
            dhke.impostaChiavePubblicaDaB64(chiavePubblicaServerB64);

            // 4) Invia DH2 (chiave pubblica client)
            if (console.valoreOutput()) Logger.log(1, "INFO: Invio della chiave DH1 in corso...");
            writer.write("DH2 " + chiavePubblicaClientB64 + " " + DHke.inBase64(saleCrittografico) + "\n");
            writer.flush();

            // 5) Accordo e derivazione chiave AES e AAD
            dhke.derivaChiaveAES(saleCrittografico);
            dhke.generaAdditionalAuthentificationData(indirizzoIP);

            messaggioIngresso = reader.readLine();
            if (messaggioIngresso.equals("handshake_completato")) { // Se il messaggio non e' quello previsto si termina il tutto
                if (console.valoreOutput()) Logger.log(1, "INFO: Handshake DH completato!");
            } else throw new RuntimeException();

            // Ricezione del nome utente e scelta stanza (interazione locale con l'utente)
            UnisciInformazioni unisciInformazioni = new UnisciInformazioni();
            String messaggioUscita;
            String messaggioUscitaCriptato;

            Logger.log(1, "");
            Logger.log(1, "Inserisci il tuo nome utente:");

            // Prima leggo il nome, poi controllo se è comando
            nomeUtente = scanner.nextLine().trim();
            while (FiltroInputConsole.corrispondeAdUnComando(nomeUtente)) {
                Logger.log(2, "WARN: Non puoi usare comandi come nome utente. Inseriscine un altro:");
                nomeUtente = scanner.nextLine().trim();
            }
            if (nomeUtente.equals("")) nomeUtente = "anonimo";

            Logger.log(1, "");
            Logger.log(1, "Scegli se entrare in una stanza o crearne una nuova!");
            Logger.log(1, "1: Genera una nuova stanza (default)");
            Logger.log(1, "2: Entra in una stanza esistente");

            int scelta = 1;
            try {
                String sceltaString = scanner.nextLine().trim();
                if (!sceltaString.equals("")) scelta = Integer.parseInt(sceltaString);
            } catch (NumberFormatException ignored) {
            }

            switch (scelta) {
                case 2:
                    boolean entrato = false;
                    while (!entrato) {
                        Logger.log(1, "");
                        Logger.log(1, "Digita il codice della stanza a 6 caratteri (oppure premi INVIO per uscire):");
                        codiceStanza = scanner.nextLine().trim();

                        if (codiceStanza.equals("")) {
                            Logger.log(2, "INFO: Nessun codice inserito, uscita dalla selezione stanza.");
                            // Se vuoto, crea stanza nuova come fallback
                            messaggioUscita = unisciInformazioni.unisciMessaggio(nomeUtente, "crea_stanza", "XXXXXX") + "\n";

                            // Cripta e invia
                            messaggioUscitaCriptato = dhke.criptaMessaggio(messaggioUscita);
                            writer.write(messaggioUscitaCriptato + "\n");
                            writer.flush();

                            entrato = true; // esco dal loop
                        } else if (codiceStanza.length() != 6) {
                            Logger.log(2, "WARN: Il codice deve essere di 6 caratteri.");
                            continue; // riprova
                        } else {
                            // Prova ad entrare nella stanza
                            messaggioUscita = unisciInformazioni.unisciMessaggio(nomeUtente, "entra_stanza", codiceStanza) + "\n";

                            // Cripta e invia
                            messaggioUscitaCriptato = dhke.criptaMessaggio(messaggioUscita);
                            writer.write(messaggioUscitaCriptato + "\n");
                            writer.flush();

                            // Attende risposta dal server
                            String rispostaCriptata = reader.readLine();
                            String risposta = dhke.decifraMessaggio(rispostaCriptata);

                            if (risposta.startsWith("entrato_nella_stanza")) {
                                Logger.log(1, "Accesso alla stanza avvenuto con successo!");
                                entrato = true; // conferma => esco dal loop
                            } else if (risposta.startsWith("errore_stanza_non_valida")) {
                                Logger.log(2, "WARN: Codice stanza non valido, riprova.");
                                // rimane in loop
                            } else {
                                Logger.log(2, "WARN: Risposta inattesa dal server: " + risposta);
                                // meglio non bloccare, rimane in loop
                            }
                        }
                    } break;

                default:
                    // Crea stanza nuova
                    messaggioUscita = unisciInformazioni.unisciMessaggio(nomeUtente, "crea_stanza", "XXXXXX") + "\n";

                    // Cripta e invia
                    messaggioUscitaCriptato = dhke.criptaMessaggio(messaggioUscita);
                    writer.write(messaggioUscitaCriptato + "\n");
                    writer.flush();
                    break;
            }

            // Avvio thread che ascolta i messaggi in arrivo dal server
            Thread gestioneRicezioneMessaggiThread = new Thread(gestioneRicezioneMessaggi);
            gestioneRicezioneMessaggiThread.start();

            // Ciclo di invio messaggi
            Logger.log(1, "");
            Logger.log(1, "Sei entrato nella stanza " + codiceStanza + " con il nome utente " + nomeUtente);
            Logger.log(1, "Puoi iniziare a scrivere messaggi!");
            Logger.log(1, "Digita \"/exit\" per terminare la sessione");
            Logger.log(1, "");
            while (!socket.isClosed()) {
                String testoUtente = scanner.nextLine();
                if (testoUtente == null || FiltroInputConsole.corrispondeAdUnComando(testoUtente)) break;
                if (testoUtente.equals("/exit")) { // Chiusura della connessione e dei threads
                    if (console.valoreOutput()) Logger.log(1, "INFO: Chiusura sessione richiesta dall'utente");
                    if (console.valoreOutput()) Logger.log(3, "INFO: Chiusura dei threads in corso...");
                    console.updateRunningStatus(false); // Chiusura thread per la console
                    gestioneRicezioneMessaggi.updateRunningStatus(false); // Chiusura thread per la ricezione messaggi
                    try { // Chiusura del socket
                        socket.close();
                    } catch (IOException e) {
                        Logger.log(3, e.getMessage());
                    }
                    break;
                } else {
                    if (testoUtente.trim().equals("")) continue;

                    // Prepara messaggio con formato: nomeUtente | msg | contenuto
                    messaggioUscita = unisciInformazioni.unisciMessaggio(nomeUtente, "msg", testoUtente) + "\n";
                    messaggioUscitaCriptato = dhke.criptaMessaggio(messaggioUscita);
                    writer.write(messaggioUscitaCriptato + "\n");
                    writer.flush();
                }
            }

        } catch (GeneralSecurityException erroreGeneraleDiSicurezza) {
            if (console.valoreOutput())
                Logger.log(3, "ERROR: Errore crittografico durante lo scambio di chiavi");
            Logger.log(3, erroreGeneraleDiSicurezza.getMessage());
        } catch (IOException erroreConnessione) {
            if (console.valoreOutput()) Logger.log(3, "ERROR: Perdita di connessione durante la sessione");
            Logger.log(3, erroreConnessione.getMessage());
        } finally { // Chiusura della connessione e dei threads
            if (console.valoreOutput()) Logger.log(3, "INFO: Chiusura dei threads in corso...");
            console.updateRunningStatus(false); // Chiusura thread per la console
            gestioneRicezioneMessaggi.updateRunningStatus(false); // Chiusura thread per la ricezione messaggi
            try { // Chiusura del socket
                socket.close();
            } catch (IOException e) {
                Logger.log(3, e.getMessage());
            }
            if (console.valoreOutput()) Logger.log(1, "INFO: Sessione terminata!");
        }
    }
}