package Tools;

// Classe per il logging colorato dei messaggi sulla console
public class Logger {
    // Codici ANSI per i colori
    private static final String RESET = "\u001B[0m";
    private static final String WHITE = "\u001B[37m";
    private static final String YELLOW = "\u001B[33m";
    private static final String RED = "\u001B[31m";

    public static void log(int codiceColore, String messaggio) {
        String color;

        switch (codiceColore) {
            case 2:  color = YELLOW; break;
            case 3:  color = RED;    break;
            default: color = WHITE;  break;
        }

        System.out.println(color + messaggio + RESET);
    }
}