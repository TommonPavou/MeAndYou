package Tools;

import javax.net.ssl.SSLSocket;
import java.util.concurrent.ExecutorService;

// Tiene traccia dei thread attivi
// Ne gestisce la chiusura in caso di un arresto forzato del server con la console
public class ClientShutter {
    // Dichiarazione e assegnazione delle variabili
    private static volatile boolean running = true;
    private static SSLSocket socket;
    private static ExecutorService threadPool;

    public static boolean isRunning() {
        return running;
    }

    public static void arrestaThreads() {
        running = false;
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close(); // sblocca accept()
            }
        } catch (Exception ignored) {}

        if (threadPool != null && !threadPool.isShutdown()) {
            threadPool.shutdownNow(); // chiude i thread delle connessioni
        }
    }
}