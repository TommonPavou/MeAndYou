package Tools;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.ThreadMXBean;
import java.util.Scanner;

// Classe per la gestione della console del server
public class Console implements Runnable {
    // Dichiarazione e assegnazione delle variabili
    String inputConsole = "";
    int valoreExtraNumerico = 1; // Valore di default
    boolean output = true;
    private volatile boolean running = true;

    // Inizializzazione dello scanner
    Scanner scanner = new Scanner(System.in);

    // Inizializzazione di metodi vari
    File cDrive = new File("C:");
    MemoryMXBean memoryMXBean = ManagementFactory.getMemoryMXBean();
    ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();

    public void run() {
        while (running) {
            // Leggi input dall'utente
            inputConsole = scanner.nextLine();

            // Gestione parametro opzionale per CPU
            if (inputConsole.startsWith("/cpu ")) {
                try {
                    String[] parti = inputConsole.split(" ");
                    inputConsole = parti[0];
                    valoreExtraNumerico = Integer.parseInt(parti[1]);
                } catch (Exception erroreDivisioneMessaggio) {
                    // Nulla al momento
                }
            }

            switch (inputConsole) {
                case "/help":
                    Logger.log(1, "/output true ->                      Visualizzare i messaggi di log");
                    Logger.log(1, "/output false ->                     Nascondere i messaggi di log");
                    Logger.log(1, "/disk ->                             Visualizzare lo spazio rimanente del disco");
                    Logger.log(1, "/cpu <secondi> ->                    Visualizzare l'utilizzo medio della CPU in un intervallo di tempo");
                    Logger.log(1, "/ram ->                              Visualizzare l'utilizzo della RAM attuale");
                    Logger.log(1, "/exit ->                             Arresta in modo sicuro la connessioni ed esci dalla stanza");
                    Logger.log(1, "");
                    break;

                case "/output true":
                    Logger.log(1, "I messaggi di log sono ora visibili");
                    Logger.log(1, "");
                    this.output = true;
                    break;

                case "/output false":
                    Logger.log(1, "I messaggi di log non sono piu' visibili");
                    Logger.log(1, "");
                    this.output = false;
                    break;

                case "/disk":
                    Logger.log(1, String.format("Utilizzo disco: %.2f%%", ((double) (cDrive.getTotalSpace() - cDrive.getFreeSpace()) / cDrive.getTotalSpace()) * 100));
                    Logger.log(1, "");
                    break;

                case "/cpu":
                    Logger.log(1, "Calcolo utilizzo CPU medio in " + valoreExtraNumerico + " secondi...");
                    Logger.log(1, String.format("Utilizzo CPU: %.2f%%", ottieniUtilizzoCPU(valoreExtraNumerico)));
                    Logger.log(1, "");
                    break;

                case "/ram":
                    Logger.log(1, String.format("Utilizzo RAM: %.2f GB", (double) memoryMXBean.getHeapMemoryUsage().getUsed() / 1073741824));
                    Logger.log(1, "");
                    break;

                case "/exit":
                    Logger.log(1, "INFO: Arresto del client in corso...");
                    ClientShutter.arrestaThreads(); // chiude socket e pool di thread
                    stop(); // Termina loop console
                    break;

                default:
                    Logger.log(2, "Comando non valido. Digitare '/help' per la lista dei comandi");
                    Logger.log(1, "");
            }
        }
    }

    // Metodo per arrestare la console
    public void stop() {
        running = false;
    }

    // Metodo per ottenere l'utilizzo medio della CPU
    private double ottieniUtilizzoCPU(int tempoCampionamento) {
        int cores = Runtime.getRuntime().availableProcessors();

        long inizioTempoCPU = ottieniTempoCPU();
        long inizioTempoReale = System.nanoTime();

        try {
            Thread.sleep(tempoCampionamento* 1000L); // Intervallo di campionamento
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        long fineTempoCPU = ottieniTempoCPU();
        long fineTempoReale = System.nanoTime();

        long tempoCPU = fineTempoCPU - inizioTempoCPU;
        long tempoReale = fineTempoReale - inizioTempoReale;

        return (tempoCPU / (double) tempoReale) / cores * 100.0;
    }

    //Somma il tempo CPU di tutti i thread
    private long ottieniTempoCPU() {
        long totale = 0L;
        for (long idThread : threadMXBean.getAllThreadIds()) {
            long tempo = threadMXBean.getThreadCpuTime(idThread);
            if (tempo > 0) {
                totale += tempo;
            }
        }
        return totale;
    }

    public boolean valoreOutput(){
        return this.output;
    }
}