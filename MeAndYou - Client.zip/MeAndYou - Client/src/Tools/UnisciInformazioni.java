package Tools;

// Classe per unire le informazioni in un singolo messaggio formattato
public class UnisciInformazioni {
    // Messaggio atteso: nomeUtente | scelta | contenuto
    // Il contenuto puo essere XXXXXX o messaggio
    public String unisciMessaggio(String nomeUtente, String scelta, String contenuto) {
        // Correzione: tutti i campi devono essere non vuoti
        if (!nomeUtente.equals("") && !scelta.equals("") && !contenuto.equals("")) {
            String messaggioFinale = nomeUtente + " | " + scelta + " | " + contenuto;
            return messaggioFinale;
        } else {
            Logger.log(3, "ERRORE: I dati forniti non sono validi o inizializzati");
            return null;
        }
    }
}