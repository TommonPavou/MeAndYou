package Tools;

// Classe per filtrare i comandi di console dai messaggi di chat
public class FiltroInputConsole {
    // Verifica se il testo è un comando di console (da escludere dal flusso chat)
    public static boolean corrispondeAdUnComando(String input) {
        if (input == null) return false;
        String testoDiviso = input.trim();

        // Gestione comando /cpu con parametro numerico opzionale (es. "/cpu" oppure "/cpu 5")
        if (testoDiviso.equals("/cpu")) return true;
        if (testoDiviso.startsWith("/cpu ")) {
            String arg = testoDiviso.substring(5).trim(); // tutto dopo "/cpu "
            // accetta solo sequenze di cifre (intero positivo)
            if (arg.matches("\\d+")) return true;
            return false;
        }

        switch (testoDiviso) {
            case "/output true":
            case "/output false":
            case "/disk":
            case "/ram":
            case "/exit":
            case "/help":
                return true;
            default:
                return false;
        }
    }

}
