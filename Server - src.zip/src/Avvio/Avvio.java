package Avvio;

import Tools.Logger;
import Tools.Console;
import Tools.ThreadCounter;
import Tools.ServerShutter;
import Connessioni.GestioneConnessioni;
import Connessioni.GestioneStanze;

import javax.net.ssl.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

// Classe principale per l'avvio del server
public class Avvio {
    // Inizializzazione e assegnazione delle costanti
    public static final java.util.List<String> VERSIONI_CONSENTITE = List.of("0.1.0");
    private static String PASSWORD_KEYSTORE = "PASSWORD_KEYSTORE";
    static final int CONNESSIONI_NASSIME = 50;
    static int PORTA_DEFAULT = 1234;

    public static void main(String[] args) {
        try {
            // Dichiarazione e assegnazione delle variabili
            boolean serverOnline = false;

            // Dichiarazione e assegnazione dei metodi vari
            Scanner scanner = new Scanner(System.in);
            ThreadPoolExecutor threadPool = null;

            // Dichiarazione dei metodi per creare il server socket
            SSLServerSocket serverSocket = null;

            Logger.log(1, " _______  _______    __            _______          ");
            Logger.log(1, "(       )(  ____ \\  /__\\ |\\     /|(  ___  )|\\     /|");
            Logger.log(1, "| () () || (    \\/ ( \\/ )( \\   / )| (   ) || )   ( |");
            Logger.log(1, "| || || || (__      \\  /  \\ (_) / | |   | || |   | |");
            Logger.log(1, "| |(_)| ||  __)     /  \\/\\ \\   /  | |   | || |   | |");
            Logger.log(1, "| |   | || (       / /\\  /  ) (   | |   | || |   | |");
            Logger.log(1, "| )   ( || (____/\\(  \\/  \\  | |   | (___) || (___) |");
            Logger.log(1, "|/     \\|(_______/ \\___/\\/  \\_/   (_______)(_______)");
            Logger.log(1, "Il nostro luogo speciale dove IO & TE siamo sovrani <3");
            Logger.log(1, "Versione server: 0.1.0");
            Logger.log(1, "Client compatibili: 0.1.0");
            Logger.log(1, "--------------------------------------------------------");
            Logger.log(1, "");

            // Loop per il setup del server
            while (!serverOnline) {
                try {
                    // Inserimento della porta del server
                    System.out.print("Inserisci la porta su cui avviare il server: ");
                    int portaInserita = PORTA_DEFAULT;
                    try {
                        portaInserita = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        Logger.log(2, "WARN: Porta non valida. Uso della porta di default: " + PORTA_DEFAULT);
                    }

                    // Inserimento delle connessioni massime del server
                    System.out.print("Inserisci il numero massimo di connessioni: ");
                    int connessioniInserite = CONNESSIONI_NASSIME;
                    try {
                        connessioniInserite = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) {
                        Logger.log(2, "WARN: Numero di connessioni non valido. Uso del numero di default: " + (CONNESSIONI_NASSIME - 3));
                    }

                    // Inserimento della password del keystore
                    System.out.print("Inserisci la password del keystore: ");
                    String passwordInserita = scanner.nextLine();
                    if (passwordInserita.isEmpty()) {
                        Logger.log(2, "WARN: Password del keystore vuota. Uso della password di default: " + PASSWORD_KEYSTORE);
                    } else {
                        PASSWORD_KEYSTORE = passwordInserita;
                    }

                    Logger.log(1, " ");
                    Logger.log(1, "INFO: Server impostato sulla porta: " + portaInserita);
                    Logger.log(1, "INFO: Connessioni massime consentite: " + connessioniInserite);
                    Logger.log(1, "INFO: Avvio del server in corso...");

                    // Crea il thread pool per gestire le connessioni
                    threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(connessioniInserite + 3); // +3 per il thread della console e ricerca di connessioni

                    // 1) Carica il keystore
                    KeyStore keyStores = KeyStore.getInstance("PKCS12");
                    InputStream keystoreStream = Avvio.class.getResourceAsStream("/keystore.p12");
                    keyStores.load(keystoreStream, PASSWORD_KEYSTORE.toCharArray());
                    Logger.log(1, "INFO: Caricamento del keystore completata");

                    // 2) Inizializza KeyManager
                    KeyManagerFactory keyManagerFactory  = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
                    keyManagerFactory.init(keyStores, "PASSWORD_KEYSTORE".toCharArray());
                    Logger.log(1, "INFO: Inizializzazione del keystore completata");

                    // 3) Inizializza SSLContext
                    SSLContext sslContext = SSLContext.getInstance("TLS");
                    sslContext.init(keyManagerFactory.getKeyManagers(), null, null);
                    Logger.log(1, "INFO: Inizializzazione del socket completata");

                    // 4) Crea SSLServerSocket
                    Logger.log(1, "INFO: Completamento creazione socket in corso...");
                    SSLServerSocketFactory sslServerSocketFactory = sslContext.getServerSocketFactory();
                    serverSocket = (SSLServerSocket) sslServerSocketFactory.createServerSocket(portaInserita);

                    // Registra il serverSocket e il threadPool dentro ServerShutter per arrestarli in futuro
                    ServerShutter.setServerSocket(serverSocket);
                    ServerShutter.setThreadPool(threadPool);

                    serverOnline = true;
                } catch (IOException | SecurityException | IllegalArgumentException | NoSuchAlgorithmException |
                         CertificateException | KeyStoreException | UnrecoverableKeyException | KeyManagementException erroreCreazioneSocket) {

                    // Il programma NON si arresta, riprova dopo 5 secondi. Niente stacktrace.
                    Logger.log(3, "ERROR: Errore durante il setup del server");
                    Logger.log(1, "INFO: Prossimo tentativo tra 5 secondi...");
                    Logger.log(1,"");
                    Thread.sleep(5000); // Riprova dopo 5 secondi a creare il server
                }
            }

            // Incremento del contatore dei threads per il processo di ricerca di connessioni in loop
            ThreadCounter.incremento();

            // Crea e avvia la gestione stanze in un thread separato
            GestioneStanze gestioneStanze = new GestioneStanze();
            threadPool.execute(gestioneStanze);
            ThreadCounter.incremento();

            // Avvia la console in un thread separato passando la gestioneStanze
            Console console = new Console(gestioneStanze);
            threadPool.execute(console);
            ThreadCounter.incremento();

            if (console.valoreOutput()) Logger.log(1, "INFO: Il server e' online!");
            if (console.valoreOutput()) Logger.log(1, "INFO: In attesa di nuove connessioni...");
            if (console.valoreOutput()) Logger.log(1, "");

            // Avvio ciclo accept
            while (ServerShutter.isRunning()) {
                if (ThreadCounter.valore() < CONNESSIONI_NASSIME){
                    try {
                        SSLSocket clientSocket = (SSLSocket) serverSocket.accept();
                        GestioneConnessioni gestioneConnessioni = new GestioneConnessioni(clientSocket, gestioneStanze, String.valueOf(clientSocket.getInetAddress()));
                        threadPool.execute(gestioneConnessioni);
                        ThreadCounter.incremento();
                        if (console.valoreOutput()) Logger.log(1, "INFO: Nuova connessione accettata. Numero di thread attivi: " + ThreadCounter.valore());
                    } catch (IOException erroreCreazioneThread) {
                        if (ServerShutter.isRunning()) {
                            if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Errore durante la creazione del thread per la connessione!");
                        }
                    }
                } else {
                    if (console.valoreOutput()) Logger.log(1, "WARN: Un client ha provato a connettersi ma il server e' pieno!");
                    if (console.valoreOutput()) Logger.log(1, "INFO: Nuovo tentativo di connessione tra 5 secondi...");
                    Thread.sleep(5000);
                }
            }

            // Chiusura server: stop console e gestione stanze
            console.stop();
            gestioneStanze.stop();

        } catch (Exception erroreGenerale) {
            Console console = Console.getInstance();
            if (console != null && console.valoreOutput()) Logger.log(3, "FATAL: Errore generale durante l'esecuzione del server!");
            if (console != null) Logger.log(3, erroreGenerale.getMessage());
            ServerShutter.arrestaThreads(); // Logica di arresto del server
        }
    }

    public int valoreConnessioniMassime() {
        return CONNESSIONI_NASSIME;
    }
}