package Connessioni;

import Tools.Console;
import Tools.Logger;

import java.security.SecureRandom;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

// Classe per la gestione della creazione, eliminazione e conta delle stanze
public class GestioneStanze implements Runnable{
    static final String CARATTERI = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private final ConcurrentHashMap<String, Stanza> stanze = new ConcurrentHashMap<>();
    int DURATA_STANZA_MINUTI = 20; // Valore di default
    private final SecureRandom secureRandom = new SecureRandom();

    // Dichiarazione dell'istanza della console
    Console console = Console.getInstance();

    // Scheduler single-thread per serializzare tutte le operazioni sulle stanze
    private ScheduledExecutorService scheduler;
    private final AtomicBoolean started = new AtomicBoolean(false);

    // Avvia il singolo thread dedicato alla gestione stanze
    public synchronized void start() {
        if (started.compareAndSet(false, true)) {
            scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread thread = new Thread(r, "GestioneStanze-Thread");
                thread.setDaemon(true);
                return thread;
            });
        }
    }

    // Arresta il thread e pulisce risorse
    public synchronized void stop() {
        if (started.compareAndSet(true, false)) {
            try {
                // Chiudi tutte le stanze
                for (String codice : stanze.keySet()) {
                    Stanza stanza = stanze.get(codice);
                    if (stanza != null) stanza.chiudi();
                }
                stanze.clear();
                if (scheduler != null && !scheduler.isShutdown()) {
                    scheduler.shutdownNow();
                }
            } catch (Exception erroreChiusura) {
                if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Err-Stop-Stanze (Codice Semplificato)");
            }
        }
    }

    // Esegue un task in modo sincrono sul thread delle stanze e ritorna risultato
    private <T> T executeSync(Callable<T> task) {
        if (scheduler == null) {
            if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Lo scheduler per la sincronizzazione delle classi non è avviato!");
            throw new IllegalStateException();
        }
        // Se siamo già nel thread dello scheduler, esegui direttamente per evitare deadlock
        if (isSchedulerThread()) {
            try {
                return task.call();
            } catch (Exception e) {
                if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Err-Task-Sync (Codice Semplificato)");
                throw new RuntimeException(e);
            }
        }
        Future<T> future = scheduler.submit(task);
        try {
            return future.get();
        } catch (InterruptedException e) {
            if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Err-Sync-Interrotto (Codice Semplificato)");
            Thread.currentThread().interrupt();
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Err-Sync-Esecuzione (Codice Semplificato)");
            throw new RuntimeException(e.getCause());
        }
    }

    // Esegue un task asincrono (senza attendere)
    private void executeAsync(Runnable task) {
        if (scheduler == null) {
            if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Lo scheduler per la sincronizzazione delle classi non è avviato!");
            throw new IllegalStateException();
        }
        // Se siamo già nel thread dello scheduler, esegui direttamente
        if (isSchedulerThread()) {
            task.run();
            return;
        }
        scheduler.execute(task);
    }

    // Permette di scheduleare un task con delay (usato dai timer delle stanze)
    public ScheduledFuture<?> schedule(Runnable eseguibile, long ritardo, TimeUnit unitaTempo) {
        if (scheduler == null) {
            if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Lo scheduler per la sincronizzazione delle classi non è avviato!");
            throw new IllegalStateException();
        }
        return scheduler.schedule(eseguibile, ritardo, unitaTempo);
    }

    // Controlla se il thread corrente è il thread dello scheduler (nome impostato in start)
    private boolean isSchedulerThread() {
        return Thread.currentThread().getName().equals("GestioneStanze-Thread");
    }

    // Implementazione del run per l'esecuzione persistente della gestione stanze
    @Override
    public void run() {
        // Avvia lo scheduler (se non già avviato)
        start();
        try {
            // Rimani in vita finché non viene chiamato stop()
            while (started.get()) {
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e) {
                    if (console != null && console.valoreOutput()) Logger.log(3, "ERROR: Err-Sleep-Stanze (Codice Semplificato)");
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        } finally {
            // Garantito cleanup
            stop();
        }
    }

    // Genera un codice stanza casuale a 6 caratteri
    private String generaCodiceInterno() {
        String codice;
        do {
            StringBuilder stringBuilder = new StringBuilder(6);
            for (int i = 0; i < 6; i++) {
                int index = secureRandom.nextInt(CARATTERI.length());
                stringBuilder.append(CARATTERI.charAt(index));
            }
            codice = stringBuilder.toString();
        } while (stanze.containsKey(codice));
        return codice;
    }

    // Crea una nuova stanza (sincrono, eseguito sul thread dedicato)
    public String creaStanza() {
        return executeSync(() -> {
            String codice = generaCodiceInterno();
            Stanza stanza = new Stanza(codice, DURATA_STANZA_MINUTI, this);
            stanze.put(codice, stanza);
            stanza.avviaTimer();
            return codice;
        });
    }

    // Recupera stanza esistente (restituisce riferimento alla stanza; le operazioni sulla stanza sono internamente serializzate)
    public Stanza ottieniStanza(String codice) {
        // Accesso sincronizzato sul thread delle stanze per coerenza
        return executeSync(() -> stanze.get(codice));
    }

    // Rimuove stanza (sincrono)
    public void rimuoviStanza(String codice) {
        executeAsync(() -> stanze.remove(codice));
    }

    // Classe interna per gestire i partecipanti
    public static class Stanza {
        private final String codice;
        private final Set<GestioneConnessioni> partecipanti = Collections.synchronizedSet(new HashSet<>());
        private final int durataMinuti;
        private final GestioneStanze gestioneStanze;
        private ScheduledFuture<?> chiusuraTask;

        public Stanza(String codice, int durataMinuti, GestioneStanze gestioneStanze) {
            this.codice = codice;
            this.durataMinuti = durataMinuti;
            this.gestioneStanze = gestioneStanze;
        }

        public void aggiungiPartecipante(GestioneConnessioni conn) {
            gestioneStanze.executeSync(() -> {
                partecipanti.add(conn);
                return null;
            });
        }

        public void rimuoviPartecipante(GestioneConnessioni conn) {
            gestioneStanze.executeSync(() -> {
                partecipanti.remove(conn);
                if (partecipanti.isEmpty()) {
                    chiudi();
                }
                return null;
            });
        }

        public int numeroPartecipanti() {
            return gestioneStanze.executeSync(partecipanti::size);
        }

        // Broadcast del messaggio a tutti i partecipanti (eseguito sul thread della gestione stanze)
        public void broadcast(String messaggioInChiaro) {
            gestioneStanze.executeAsync(() -> {
                synchronized (partecipanti) {
                    for (GestioneConnessioni conn : partecipanti) {
                        conn.inviaMessaggioInStanza(messaggioInChiaro);
                    }
                }
            });
        }

        // Avvia il timer della stanza (usa lo scheduler della GestioneStanze)
        public void avviaTimer() {
            // Notifica immediata dopo pochi secondi
            gestioneStanze.schedule(() -> broadcast("SERVER | La stanza durerà " + durataMinuti + " minuti\n"),
                    10, TimeUnit.SECONDS);

            // Avviso a -5 minuti
            if (durataMinuti > 5) {
                gestioneStanze.schedule(() -> broadcast("SERVER | Mancano 5 minuti alla chiusura della stanza\n"),
                        (durataMinuti - 5), TimeUnit.MINUTES);
            }

            // Avviso a -1 minuto
            if (durataMinuti > 1) {
                gestioneStanze.schedule(() -> broadcast("SERVER | Manca 1 minuto alla chiusura della stanza\n"),
                        (durataMinuti - 1), TimeUnit.MINUTES);
            }

            // Task di chiusura
            chiusuraTask = gestioneStanze.schedule(() -> {
                broadcast("SERVER | La stanza è scaduta e verrà chiusa\n");
                chiudi();
            }, durataMinuti, TimeUnit.MINUTES);
        }

        // Chiude la stanza definitivamente
        public void chiudi() {
            gestioneStanze.executeSync(() -> {
                if (chiusuraTask != null && !chiusuraTask.isDone()) {
                    chiusuraTask.cancel(false);
                }
                gestioneStanze.rimuoviStanza(codice);
                partecipanti.clear();
                return null;
            });
        }
    }
}