package Connessioni;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// Classe per la protezione contro attacchi DoS verificando il numero di connessioni da un singolo IP in un lasso di tempo
public class ProtezioneDoS {
    // Inizializzazione e assegnazione delle costanti
    private final int MAX_CONNESSIONI = 2; // Massimi tentativi per IP
    private final long INTERVALLO_MS = 5000; // Timer di 5 secondi

    // Inizializzazione e assegnazione delle variabili
    private final ConcurrentHashMap<String, Integer> connessioni = new ConcurrentHashMap<>(); // Tentativi eseguiti da un IP (in un determinato lasso di tempo)
    private final ConcurrentHashMap<String, Long> ultimoReset = new ConcurrentHashMap<>(); // Ultimo reset del timer

    public boolean verificaConnessione(String ip) {
        long orario = System.currentTimeMillis();

        // Previene il Memory Leak in caso di DDoS da indirizzi inattivi
        if (ultimoReset.size() > 1000) {
            Iterator<Map.Entry<String, Long>> iteratore = ultimoReset.entrySet().iterator();
            while (iteratore.hasNext()) {
                Map.Entry<String, Long> entry = iteratore.next();
                if (orario - entry.getValue() > INTERVALLO_MS) {
                    connessioni.remove(entry.getKey());
                    iteratore.remove();
                }
            }
        }

        // Salvare l'IP in memoria
        if (!ultimoReset.containsKey(ip)) {
            ultimoReset.put(ip, orario);
            connessioni.put(ip, 0);
        }

        // Se è passato troppo tempo, resetto il contatore
        if (orario - ultimoReset.get(ip) > INTERVALLO_MS) {
            connessioni.put(ip, 0);
            ultimoReset.put(ip, orario);
        }

        // Incremento il numero di connessioni
        int num = connessioni.get(ip) + 1;
        connessioni.put(ip, num);

        // Se supera il massimo delle connessioni restituisci false
        return num <= MAX_CONNESSIONI;
    }
}