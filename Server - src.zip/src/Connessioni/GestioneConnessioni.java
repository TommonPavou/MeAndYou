package Connessioni;

import Criptografia.DHke;
import Tools.Console;
import Tools.Logger;
import Tools.ThreadCounter;
import Tools.ServerShutter;
import Tools.DividiInformazioni;

import javax.net.ssl.SSLSocket;
import java.io.*;
import java.security.GeneralSecurityException;

// Classe per la gestione delle connessioni in entrata e gestione dei messaggi
public class GestioneConnessioni implements Runnable {
    // Inizializzazione e assegnazione delle variabili
    String clientIP;
    String nomeUtente;
    static final java.util.List<String> VERSIONI_CONSENTITE = Avvio.Avvio.VERSIONI_CONSENTITE; // Lista delle versioni client consentite

    // Assegnazione del ServerSocket
    public GestioneConnessioni(SSLSocket clientSocket, GestioneStanze gestioneStanze, String clientIP) {
        this.clientSocket = clientSocket;
        this.gestioneStanze = gestioneStanze;
        this.clientIP = clientIP;
    }

    // Inizializzazione e assegnazione delle variabili
    SSLSocket clientSocket;
    private BufferedWriter writer;

    // Dichiarazione e assegnazione di metodi vari
    DHke dhke;
    ProtezioneDoS protezioneDoS = new ProtezioneDoS();
    Tools.Console console = Console.getInstance(); // Usa l'istanza condivisa (impostata in Avvio)
    GestioneStanze gestioneStanze;
    private volatile GestioneStanze.Stanza stanzaCorrente;

    // Metodo per cifrare ed inviare un messaggio in chiaro a QUESTO specifico client
    public void inviaMessaggioInStanza(String testoChiaro) {
        try {
            if (writer != null && dhke != null) {
                synchronized (writer) {
                    writer.write(dhke.criptaMessaggio(testoChiaro) + "\n");
                    writer.flush();
                }
            }
        } catch (Exception erroreInvioMessaggio) {
            // Il programma non si arresta qui
            if (console != null && console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Errore durante il broadcast del messaggio nella stanza");
        }
    }

    public void run() {
        try {
            clientIP = clientSocket.getInetAddress().getHostAddress();
            // inizializza dhke ora che abbiamo l'IP corretto
            dhke = new DHke(clientIP);
            // recupera l'istanza di Console (dovrebbe essere stata creata in Avvio)
            console = Console.getInstance();

            // Controllo per connessione già esistente
            if (GestioneConnessioniAttive.getConnessione(clientIP) != null) {
                if (console != null && console.valoreOutput())
                    Logger.log(3, clientIP + " ERROR: Connessione interrotta, l'IP è gia' connesso");
                return; // Chiude la connessione passando l'esecuzione al blocco catch e finally
            }

            // Accettazione connessione e controllo per DoS
            GestioneConnessioniAttive.registraConnessione(clientIP, this);
            if (!protezioneDoS.verificaConnessione(clientIP)) {
                if (console != null && console.valoreOutput())
                    Logger.log(3, clientIP + " ERROR: Connessione interrotta per sospetto DoS");
                return; // Chiude la connessione passando l'esecuzione al blocco catch e finally
            }

            if (console != null && console.valoreOutput())
                Logger.log(1, clientIP + " INFO: Connessione stabilita con il client");

            // Assegnazione della variabile per la ricezione dei messaggi
            String messaggioIngresso;

            // Assegnazione delle variabili per la ricezione e invio delle chiavi
            String chiavePubblicaServerB64;
            String chiavePubblicaClientB64;

            // Preparazione dei buffer per la comunicazione con il client e le variabili
            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Preparazione dei buffer in corso...");
            InputStream inputStream = clientSocket.getInputStream();
            OutputStream outputStream = clientSocket.getOutputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            this.writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Buffer impostati correttamente");

            // 0) Verifica della versione del client
            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: In attesa della versione del client...");

            messaggioIngresso = reader.readLine();
            if (messaggioIngresso == null) {
                throw new IOException(); // Chiude la connessione passando l'esecuzione al blocco catch e finally
            }

            String versioneClient = messaggioIngresso.replace("VERSIONE ", "").trim();
            if (VERSIONI_CONSENTITE.contains(versioneClient)) {
                if (console != null && console.valoreOutput()) Logger.log(2, clientIP + " WARN: Versione del client non supportata");

                // Invia le versioni consentite in chiaro al client e arresta il thread in sicurezza
                writer.write("errore_versione_non_supportata | Versioni consentite: " + String.join(", ", VERSIONI_CONSENTITE) + "\n");
                writer.flush();
                return; // Chiude la connessione passando l'esecuzione al blocco catch e finally
            }

            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Versione client accettata (" + versioneClient + ")");

            // 1) Server genera le chiavi (privata e pubblica)
            dhke.generaCoppiaChiavi();
            chiavePubblicaServerB64 = dhke.valoreChiavePubblicaLocaleDaB64();

            // 2) Imposta il sale crittografico con SecureRandom
            byte[] saleCrittografico = DHke.generaSaleCrittografico();

            // 3) Invia DH1 (chiave pubblica server)
            if (console != null && console.valoreOutput())
                Logger.log(1, clientIP + " INFO: Invio della chiave DH1 in corso...");
            writer.write("DH1 " + chiavePubblicaServerB64 + " " + DHke.inBase64(saleCrittografico) + "\n");
            writer.flush();

            // 4) Riceve DH2 (chiave pubblica client)
            if (console != null && console.valoreOutput())
                Logger.log(1, clientIP + " INFO: Recezione della chiave DH2 in corso...");
            messaggioIngresso = reader.readLine();
            if (messaggioIngresso == null || !messaggioIngresso.startsWith("DH2 ")) { // Verifica che il messaggio sia la chiave DH2
                throw new IOException(); // Chiude la connessione passando l'esecuzione al blocco catch e finally
            }
            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Chiave DH2 ricevuta");
            chiavePubblicaClientB64 = messaggioIngresso.split(" ", 2)[1].trim();
            dhke.impostaChiavePubblicaDaB64(chiavePubblicaClientB64);

            // 5) Accordo e derivazione chiave AES e AAD
            dhke.derivaChiaveAES(saleCrittografico);
            dhke.generaAdditionalAuthentificationData(clientIP);

            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Handshake DH completato!");

            // 6) Conferma al client che l'handshake è riuscito
            writer.write("handshake_completato\n");
            writer.flush(); // FINE KEY EXCHANGE
            if (console != null && console.valoreOutput()) Logger.log(1, "");

            // Classe per la divisione dei messaggi
            DividiInformazioni dividiInformazioni = new DividiInformazioni();

            // ------------------------------------------------------------------------------
            // NOTA: D'ora in avanti i messaggi sono criptati mediante la chiave AES derivata
            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Ricezione istruzioni e nome utente in corso...");
            while (true) { // Verifica se il messaggio successivo e' quello previsto
                messaggioIngresso = dhke.decifraMessaggio(reader.readLine());

                // Il messaggio previsto ha la seguente sintassi: "nomeUtente | azione_stanza | dettagli"
                if (messaggioIngresso.contains("| crea_stanza | ") || messaggioIngresso.contains("| entra_stanza | "))
                    break;
                else {
                    if (console != null && console.valoreOutput())
                        Logger.log(2, clientIP + " WARN: Il messaggio ricevuto non rispetta la sintassi prevista");
                    if (console != null && console.valoreOutput())
                        Logger.log(2, clientIP + " WARN: Il client e server potrebbero essere out-of-sync");
                    if (console != null && console.valoreOutput())
                        Logger.log(1, clientIP + " INFO: In attesa del messaggio previsto...");
                }
            }

            // Ottiene il nome utente del client connesso dal messaggio ricevuto
            nomeUtente = dividiInformazioni.ottieniNome(messaggioIngresso);
            if (console != null && console.valoreOutput())
                Logger.log(1, clientIP + "INFO: Nome utente del client: " + nomeUtente);

            // Inizializza la stanza dell'utente
            this.stanzaCorrente = null;

            // Assegnazioni delle variabili per la divisione dei messaggi di ingresso
            String scelta;
            String contenuto;
            String rigaLetta;

            // Loop principale per il ricevimento di messaggi dal client
            while (ServerShutter.isRunning()) {
                // Garantisce la corretta gestione della chiusura improvvisa del client evitando NullpointerException
                rigaLetta = reader.readLine();
                if (rigaLetta == null) {
                    if (console != null && console.valoreOutput()) Logger.log(2, clientIP + " WARN: Il client ha chiuso la connessione in modo imprevisto");
                    if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Chiusura della connessione in corso...");
                    throw new IOException(); // Chiude la connessione passando l'esecuzione al blocco catch e finally
                }
                messaggioIngresso = dhke.decifraMessaggio(rigaLetta);

                scelta = dividiInformazioni.ottieniAzioneScelta(messaggioIngresso);
                contenuto = dividiInformazioni.ottieniContenuto(messaggioIngresso);

                // In base alla scelta inclusa nel messaggio completa una determinata azione
                switch (scelta) {
                    // Crea stanza e unisci l'utente
                    case "crea_stanza":
                        if (console != null && console.valoreOutput())
                            Logger.log(1, clientIP + " INFO: Creazione stanza in corso...");
                        String codiceStanza = gestioneStanze.creaStanza();
                        this.stanzaCorrente = gestioneStanze.ottieniStanza(codiceStanza);

                        writer.write(dhke.criptaMessaggio("stanza_creata | " + codiceStanza + "\n"));
                        writer.flush();

                        // Registra l'oggetto GestioneConnessioni
                        stanzaCorrente.aggiungiPartecipante(this);

                        if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Stanza con codice " + codiceStanza + "generata con successo!");
                        stanzaCorrente.broadcast("SERVER | Nuova stanza con codice " + codiceStanza + " creata con successo\n");
                        break;

                    // Entra in una stanza pre esistente
                    case "entra_stanza":
                        if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Accesso in una stanza in corso...");
                        this.stanzaCorrente = gestioneStanze.ottieniStanza(contenuto); // Il contenuto risponde al codice della stanza
                        if (stanzaCorrente != null) {
                            writer.write(dhke.criptaMessaggio("entrato_nella_stanza | " + contenuto + "\n"));
                            writer.flush();

                            // Registra l'oggetto GestioneConnessioni
                            stanzaCorrente.aggiungiPartecipante(this);

                            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Il client e' entrato nella stanza " + contenuto); // Il contenuto risponde al codice della stanza

                            // Il metodo broadcast cripta il messaggio usando la chiave crittografica dei singoli client nella stanza
                            stanzaCorrente.broadcast("SERVER | " + nomeUtente + " è entrato nella stanza\n");
                        } else {
                            if (console != null && console.valoreOutput()) Logger.log(2, clientIP + " WARN: Errore nell' accesso alla stanza " + contenuto); // Il contenuto risponde al codice della stanza
                            writer.write(dhke.criptaMessaggio("errore_stanza_non_valida\n"));
                            writer.flush();
                        }
                        break;

                    // Scrivi un messaggio
                    case "msg":
                        if (stanzaCorrente != null) {
                            // Il metodo broadcast cripta il messaggio usando la chiave crittografica dei singoli client nella stanza
                            stanzaCorrente.broadcast(nomeUtente + " | " + contenuto + "\n");
                            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + ": " + nomeUtente + " | " + contenuto);
                        } else {
                            writer.write(dhke.criptaMessaggio("errore_non_in_stanza\n"));
                            writer.flush();
                            if (console != null && console.valoreOutput()) Logger.log(2, clientIP + " WARN: Errore nell' invio di un messaggio");
                        }
                        break;

                    // Messaggio fantasma
                    case "":
                        // Ignora il messaggio fantoccio
                        break;

                    // Scelta non esistente
                    default:
                        writer.write(dhke.criptaMessaggio("errore_comando_non_valido\n"));
                        writer.flush();
                        if (console != null && console.valoreOutput()) Logger.log(2, clientIP + " WARN: Errore nell' interpretazione dell' istruzione " + scelta);
                        break;
                }
            }

        } catch (GeneralSecurityException erroreDiSicurezza) {
            if (console != null && console.valoreOutput()) Logger.log(3, clientIP + " FATAL: Errore di sicurezza durante la connessione!");
            if (console != null) Logger.log(3, clientIP + " " + erroreDiSicurezza.getMessage());
        } catch (Exception erroreConnessione) {
            if (console != null && console.valoreOutput()) Logger.log(3, clientIP + " FATAL: Errore generale durante la connessione!");
            if (console != null) Logger.log(3, clientIP + " " + erroreConnessione.getMessage());
        } finally {
            try {
                if (console != null && console.valoreOutput()) Logger.log(3, clientIP + " INFO: Chiusura socket in corso...");
                if (stanzaCorrente != null) {
                    stanzaCorrente.rimuoviPartecipante(this);

                    // Notifica agli altri partecipanti solo se la stanza non è vuota
                    if (stanzaCorrente.numeroPartecipanti() > 0) {
                        stanzaCorrente.broadcast("SERVER | " + nomeUtente + " si è disconnesso\n");
                    }
                }

                // Chiusura della connessione
                if (clientSocket != null) clientSocket.close();
                GestioneConnessioniAttive.rimuoviConnessione(clientIP);
            } catch (IOException erroreChiusuraSocket) {
                if (console != null && console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Errore durante la chiusura forzata del socket");
            }

            // Aggiornamento numero thread attivi
            if (console != null && console.valoreOutput()) Logger.log(1, clientIP + " INFO: Sessione terminata!");
            ThreadCounter.decremento();
            if (console != null && console.valoreOutput()) Logger.log(1, "INFO: Numero di thread attivi aggiornato: " + ThreadCounter.valore());
        }
    }

    // Metodo per terminare la sessione in modo forzato
    public void terminaSessioneSpecifica(String motivo) {
        try {
            if (stanzaCorrente != null) {
                // Il metodo broadcast cripta il messaggio usando la chiave crittografica dei singoli client nella stanza
                stanzaCorrente.broadcast("SERVER | " + nomeUtente + " è stato espulso. Motivazione: " + motivo + "\n");
                stanzaCorrente.rimuoviPartecipante(this);
            }

            // Chiusura della connessione e aggiornamento della lista/conta delle connessioni attive
            clientSocket.close();
            GestioneConnessioniAttive.rimuoviConnessione(clientIP);
        } catch (IOException erroreGenerale) {
            if (console != null && console.valoreOutput()) Logger.log(3, clientIP + " ERROR: Errore generale durante la chiusura del socket");
        }
    }
}