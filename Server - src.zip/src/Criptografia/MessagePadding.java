package Criptografia;

import Tools.Logger;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

// Classe per aggiunge e rimuove il padding dai messaggi
public class MessagePadding {
    // Dichiarazione e assegnazione di metodi vari
    private static final SecureRandom secureRandom = new SecureRandom();

    // Prepara un messaggio con il prefisso LEN e il padding con SecureRandom
    public static byte[] addPadding(String messaggioChiaro, int lunghezzaTotale, String clientIP) {
        byte[] data = messaggioChiaro.getBytes(StandardCharsets.UTF_8);
        String prefisso = "LEN:" + data.length + "|";
        byte[] prefissoBytes = prefisso.getBytes(StandardCharsets.UTF_8);

        int dimensioneContenuto = prefissoBytes.length + data.length;
        if (dimensioneContenuto > lunghezzaTotale) {
            Logger.log(3, clientIP + " ERROR: Messaggio troppo lungo per la dimensione target");
            throw new IllegalArgumentException();
        }

        int paddingRimasto = lunghezzaTotale - dimensioneContenuto;
        byte[] padding = new byte[paddingRimasto];
        secureRandom.nextBytes(padding);

        byte[] messaggioFinale = new byte[lunghezzaTotale];
        System.arraycopy(prefissoBytes, 0, messaggioFinale, 0, prefissoBytes.length);
        System.arraycopy(data, 0, messaggioFinale, prefissoBytes.length, data.length);
        System.arraycopy(padding, 0, messaggioFinale, dimensioneContenuto, paddingRimasto);

        return messaggioFinale;
    }

    // Estrae il messaggio reale dal prefisso LEN e il padding
    public static String removePadding(byte[] messaggioChiaro, String clientIP) {
        String strStart = new String(messaggioChiaro, 0, Math.min(30, messaggioChiaro.length), StandardCharsets.UTF_8);
        if (!strStart.startsWith("LEN:")) {
            Logger.log(3, clientIP + " ERROR: Formato del messaggio fornito non valido");
            throw new IllegalStateException();
        }

        int indiceSeparatore = strStart.indexOf('|');
        if (indiceSeparatore == -1) {
            Logger.log(3, clientIP + " ERROR: Formato del messaggio fornito non valido");
            throw new IllegalStateException();
        }

        int lunghezzaOriginaleByte = Integer.parseInt(strStart.substring(4, indiceSeparatore));
        int offsetMessaggioByte = ("LEN:" + lunghezzaOriginaleByte + "|").getBytes(StandardCharsets.UTF_8).length;

        if (offsetMessaggioByte + lunghezzaOriginaleByte > messaggioChiaro.length) {
            Logger.log(3, clientIP + " ERROR: Dimensione del messaggio non coerente con i dati ricevuti");
            throw new IllegalStateException();
        }

        return new String(messaggioChiaro, offsetMessaggioByte, lunghezzaOriginaleByte, StandardCharsets.UTF_8);
    }
}